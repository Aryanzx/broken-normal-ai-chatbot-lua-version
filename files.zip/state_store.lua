-- ================================================================
--  state_store.lua  ─  Unified State Transition & Case Compression
--  Architecture v2.0 — Full Lua CPU Implementation
--
--  Budget:  ~2.5 GB total   (In-Memory ~541 MB | On-Disk ~1.99 GB)
--  States:  10M hot + 10M cold
--  Cases:   100M
--  Patterns:10K
--
--  Components:
--    1. Bloom Filter           (25 MB memory,  12-bit / 20M states)
--    2. Transition Core (HOT)  (505 MB memory, MPHF-style hash map)
--    3. Cold Archive           (489 MB disk,   LZ4-bucket indexed)
--    4. Case Library           (1.5 GB disk,   zstd block-compressed)
--    5. Pattern Dictionary     (5 MB memory,   template + slot system)
-- ================================================================

local ffi_ok, ffi = pcall(require, "ffi")

-- ────────────────────────────────────────────────────────────────
--  §A  ENCODING HELPERS
-- ────────────────────────────────────────────────────────────────

local Enc = {}

-- FNV-1a 32-bit  (spec §9 reference card)
function Enc.fnv1a32(s)
    local h = 2166136261
    for i = 1, #s do
        h = (h ~ string.byte(s,i)) & 0xFFFFFFFF
        h = (h * 16777619)         & 0xFFFFFFFF
    end
    return h
end

-- FNV-1a 64-bit  (collision resolution)
function Enc.fnv1a64(s)
    local lo, hi = 2166136261, 0
    local p_lo,  p_hi  = 16777619, 0   -- prime fits in 32 bits
    for i = 1, #s do
        local b = string.byte(s,i)
        -- XOR
        lo = lo ~ b
        -- Multiply 64-bit: (hi:lo) * prime
        local nlo = (lo * p_lo) & 0xFFFFFFFF
        local nhi = (hi * p_lo + math.floor(lo * p_lo / 0x100000000)) & 0xFFFFFFFF
        lo, hi = nlo, nhi
    end
    return hi, lo   -- returns hi:lo pair
end

-- Varint encode  (spec §9: bit7=continue, bits0-6=payload)
function Enc.varint_encode(n)
    local bytes = {}
    repeat
        local b = n & 0x7F
        n = n >> 7
        if n > 0 then b = b | 0x80 end
        bytes[#bytes+1] = string.char(b)
    until n == 0
    return table.concat(bytes)
end

function Enc.varint_decode(s, pos)
    pos = pos or 1
    local v, shift = 0, 0
    repeat
        local b = string.byte(s, pos); pos = pos + 1
        v = v | ((b & 0x7F) << shift)
        shift = shift + 7
    until (string.byte(s, pos-1) & 0x80) == 0
    return v, pos
end

-- Log-scale 12-bit probability  (spec §3 TransitionEntry)
-- encode(p) = round(-log2(p) × 256)  stored in 12 bits
function Enc.prob_encode12(p)
    if p <= 0 then return 4095 end
    if p >= 1 then return 0    end
    return math.min(4095, math.max(0, math.floor(-math.log(p, 2) * 256 + 0.5)))
end

function Enc.prob_decode12(v)
    if v == 0    then return 1.0 end
    if v == 4095 then return 0.0 end
    return math.pow and math.pow(2, -v/256) or 2^(-v/256)
end

-- 24-bit LE integer pack / unpack
function Enc.pack24(n)
    return string.char(n & 0xFF, (n>>8)&0xFF, (n>>16)&0xFF)
end
function Enc.unpack24(s, pos)
    pos = pos or 1
    return string.byte(s,pos) | (string.byte(s,pos+1)<<8) | (string.byte(s,pos+2)<<16)
end

-- 32-bit LE
function Enc.pack32(n)
    n = n & 0xFFFFFFFF
    return string.char(n&0xFF,(n>>8)&0xFF,(n>>16)&0xFF,(n>>24)&0xFF)
end
function Enc.unpack32(s, pos)
    pos = pos or 1
    return (string.byte(s,pos)) | (string.byte(s,pos+1)<<8) |
           (string.byte(s,pos+2)<<16) | (string.byte(s,pos+3)<<24)
end

-- 48-bit LE (for case_id timestamp)
function Enc.pack48(n)
    return string.char(n&0xFF,(n>>8)&0xFF,(n>>16)&0xFF,
                       (n>>24)&0xFF,(n>>32)&0xFF,(n>>40)&0xFF)
end

-- File header (64 bytes)  magic(4) + ver_major(1) + ver_minor(1) +
-- flags(2) + entry_count(4) + data_size_raw(8) + data_size_stored(8) +
-- created_at_ms(8) + checksum_sha256(32, zeroed here) = 68 → pad to 64
-- Simplified: we skip SHA-256, use CRC32 per block only.
local MAGIC = {
    CTC = "CTC\0",  -- Compact Transition Core
    CCL = "CCL\0",  -- Compact Case Library
    PDT = "PDT\0",  -- Pattern Dictionary Table
    CAR = "CAR\0",  -- Cold Archive
    BLF = "BLF\0",  -- Bloom Filter
}

function Enc.file_header(magic, entry_count, raw_size, stored_size)
    local ts = os.time() * 1000   -- ms
    return  magic ..
            string.char(2, 0) ..   -- version 2.0
            Enc.pack32(0) ..        -- flags (LE, no compression flag in header)
            Enc.pack32(entry_count) ..
            Enc.pack32(raw_size & 0xFFFFFFFF) ..
            Enc.pack32((raw_size >> 32) & 0xFFFFFFFF) ..
            Enc.pack32(stored_size & 0xFFFFFFFF) ..
            Enc.pack32((stored_size >> 32) & 0xFFFFFFFF) ..
            Enc.pack32(ts & 0xFFFFFFFF) ..
            Enc.pack32((ts >> 32) & 0xFFFFFFFF) ..
            string.rep("\0", 28)    -- reserved / checksum placeholder
    -- Total = 4+2+4+4+4+4+4+4+4+4+28 = 62 + 2 pad = 64
end

-- Simple CRC32 (Castagnoli polynomial) for block integrity
local CRC32_TABLE
local function crc32_init()
    CRC32_TABLE = {}
    for i = 0, 255 do
        local c = i
        for _ = 1, 8 do
            if c & 1 == 1 then c = 0xEDB88320 ~ (c >> 1)
            else c = c >> 1 end
        end
        CRC32_TABLE[i] = c
    end
end

function Enc.crc32(s, crc)
    if not CRC32_TABLE then crc32_init() end
    crc = crc and (~crc & 0xFFFFFFFF) or 0xFFFFFFFF
    for i = 1, #s do
        crc = CRC32_TABLE[(crc ~ string.byte(s,i)) & 0xFF] ~ (crc >> 8)
    end
    return (~crc) & 0xFFFFFFFF
end

-- ────────────────────────────────────────────────────────────────
--  §1  BLOOM FILTER  (25 MB, covers 20M states, 10 bits/element)
-- ────────────────────────────────────────────────────────────────
--  Blocked variant: each element maps to one 512-bit (64B) block
--  → all k=7 probes stay in one cache line
-- ────────────────────────────────────────────────────────────────

local BloomFilter = {}
BloomFilter.__index = BloomFilter

function BloomFilter.new(n_elements, bits_per_elem)
    local self = setmetatable({}, BloomFilter)
    n_elements   = n_elements   or 20000000
    bits_per_elem = bits_per_elem or 10
    self.n_bits   = n_elements * bits_per_elem          -- 200M bits
    self.n_blocks = math.ceil(self.n_bits / 512)        -- 512 bits/block
    self.k        = 7                                    -- hash functions

    -- Bit array stored as array of 32-bit integers
    -- Each block = 16 uint32 = 512 bits
    self.n_words  = self.n_blocks * 16
    self.bits     = {}
    for i = 1, self.n_words do self.bits[i] = 0 end

    self.n_elements = n_elements
    self.count      = 0
    return self
end

-- Double-hashing: h_i(x) = h1(x) + i * h2(x) mod bits_per_block
function BloomFilter:_probes(hash32)
    -- Two independent hashes from one 32-bit value (Kirsch-Mitzenmacher)
    local h1 = Enc.fnv1a32(Enc.pack32(hash32))
    local h2 = Enc.fnv1a32(Enc.pack32(hash32 ~ 0xDEADBEEF))
    -- Block selection
    local block = h1 % self.n_blocks   -- which 512-bit block
    local probes = {}
    for i = 0, self.k-1 do
        probes[i+1] = (h1 + i * h2) % 512  -- bit within block
    end
    return block, probes
end

function BloomFilter:_set_bit(block, bit_in_block)
    local word_offset = block * 16 + math.floor(bit_in_block / 32)
    local bit_pos     = bit_in_block % 32
    self.bits[word_offset + 1] = self.bits[word_offset + 1] | (1 << bit_pos)
end

function BloomFilter:_get_bit(block, bit_in_block)
    local word_offset = block * 16 + math.floor(bit_in_block / 32)
    local bit_pos     = bit_in_block % 32
    return (self.bits[word_offset + 1] >> bit_pos) & 1
end

-- Returns true = MAYBE_EXISTS, false = DEFINITELY_NOT
function BloomFilter:check(hash32)
    local block, probes = self:_probes(hash32)
    for _, bit in ipairs(probes) do
        if self:_get_bit(block, bit) == 0 then return false end
    end
    return true
end

function BloomFilter:add(hash32)
    local block, probes = self:_probes(hash32)
    for _, bit in ipairs(probes) do
        self:_set_bit(block, bit)
    end
    self.count = self.count + 1
end

-- FPR estimate at current fill
function BloomFilter:fpr()
    local filled = self.count * self.k / self.n_bits
    return (1 - math.exp(-filled)) ^ self.k
end

function BloomFilter:save(path)
    local f = assert(io.open(path, "wb"))
    f:write(Enc.file_header(MAGIC.BLF, self.n_elements,
            #self.bits*4, #self.bits*4))
    for i = 1, self.n_words do
        f:write(Enc.pack32(self.bits[i] or 0))
    end
    f:close()
    print(("[Bloom] Saved %d bits → %s  FPR≈%.3f%%"):format(
          self.n_bits, path, self:fpr()*100))
end

function BloomFilter:load(path)
    local f = io.open(path, "rb")
    if not f then return false end
    f:read(64)   -- skip header
    for i = 1, self.n_words do
        local chunk = f:read(4)
        if chunk and #chunk == 4 then
            self.bits[i] = Enc.unpack32(chunk)
        end
    end
    f:close()
    print("[Bloom] Loaded from " .. path)
    return true
end

-- ────────────────────────────────────────────────────────────────
--  §2  TRANSITION CORE (HOT)
--  Stores 10M StateEntry records in memory.
--  Uses open-addressing hash map (approximates MPHF behaviour).
--  TransitionEntry = 5 bytes:
--    [0-2] target_state_24  (direct index, LE)
--    [3]   prob_hi_8        (upper 8 bits of 12-bit prob)
--    [4]   prob_lo4_type4   (lower 4 bits prob | 4 bits type)
-- ────────────────────────────────────────────────────────────────

--  StateEntry fields:
--    stored_hash   : uint32
--    state_n_flags : uint8  (bits 0-2: n_value offset, 3:terminal,
--                             4:has_extended, 5:pattern_root)
--    total_count   : varint
--    num_trans     : uint8
--    transitions[] : N × 5 bytes
--    (offset table separate, managed by core)

local TransitionCore = {}
TransitionCore.__index = TransitionCore

-- Transition type constants (spec §3)
local TRANS_TYPE = {
    DIRECT      = 0x0,
    BACKOFF     = 0x1,
    INTERPOLATED= 0x2,
    INFERRED    = 0x3,
    FORCED      = 0x4,
    DECAY       = 0x5,
    EXTENDED    = 0xF,
}

function TransitionCore.new(max_hot)
    local self = setmetatable({}, TransitionCore)
    self.max_hot    = max_hot or 10000000
    self.capacity   = math.floor(max_hot * 1.4)  -- 40% load headroom
    -- Hash map: hash32 → StateEntry table
    self.slots      = {}   -- idx → { hash, entry }
    self.n_entries  = 0
    -- Collision table: hash32 → list of (hash64_hi, hash64_lo, entry)
    self.collisions = {}
    -- Extended transitions overflow (for states with >254 transitions)
    self.extended   = {}   -- hash32 → list of TransitionEntry tables
    -- Staging area for promoted cold states (pre-MPHF-rebuild)
    self.staging    = {}   -- hash32 → entry
    return self
end

-- Build a TransitionEntry (returns a Lua table; serialised on save)
function TransitionCore.make_transition(target_idx, probability, trans_type)
    return {
        target  = target_idx & 0xFFFFFF,
        prob12  = Enc.prob_encode12(probability),
        ttype   = trans_type or TRANS_TYPE.DIRECT,
    }
end

-- Serialise one TransitionEntry → 5 bytes
function TransitionCore.pack_transition(t)
    local prob_hi = (t.prob12 >> 4) & 0xFF
    local prob_lo = (t.prob12 & 0x0F) << 4
    local ttype   = t.ttype & 0x0F
    return Enc.pack24(t.target) ..
           string.char(prob_hi) ..
           string.char(prob_lo | ttype)
end

function TransitionCore.unpack_transition(s, pos)
    pos = pos or 1
    local target  = Enc.unpack24(s, pos)
    local prob_hi = string.byte(s, pos+3)
    local byte4   = string.byte(s, pos+4)
    local prob12  = (prob_hi << 4) | (byte4 >> 4)
    local ttype   = byte4 & 0x0F
    return {
        target = target,
        prob12 = prob12,
        prob   = Enc.prob_decode12(prob12),
        ttype  = ttype,
    }, pos + 5
end

-- Open-addressing: slot for a hash
function TransitionCore:_slot(hash32)
    return (hash32 % self.capacity) + 1
end

function TransitionCore:_find_slot(hash32)
    local s = self:_slot(hash32)
    local start = s
    while self.slots[s] do
        if self.slots[s].hash == hash32 then return s, true end
        s = (s % self.capacity) + 1
        if s == start then return nil, false end   -- full
    end
    return s, false
end

-- Insert or update a state entry
-- entry: { hash, n, flags, count, transitions[], terminal, pattern_root }
function TransitionCore:put(entry)
    local hash32 = entry.hash
    local slot, found = self:_find_slot(hash32)

    if not slot then
        -- Table full – should not happen with 40% headroom
        print("[TC] WARNING: hash table full, inserting to staging")
        self.staging[hash32] = entry
        return
    end

    if found then
        -- Merge: keep higher count, union transitions
        local existing = self.slots[slot].entry
        existing.count = math.max(existing.count, entry.count)
        -- Add new transitions
        for _, t in ipairs(entry.transitions or {}) do
            existing.transitions[#existing.transitions+1] = t
        end
    else
        self.slots[slot] = { hash = hash32, entry = entry }
        self.n_entries = self.n_entries + 1
    end
end

function TransitionCore:get(hash32)
    -- 1. Check staging first
    if self.staging[hash32] then return self.staging[hash32] end
    -- 2. Open-address lookup
    local slot, found = self:_find_slot(hash32)
    if found and slot then return self.slots[slot].entry end
    return nil
end

-- Rebuild: re-normalise transition probabilities for all states
function TransitionCore:normalise_probs()
    local fixed = 0
    for _, slot in pairs(self.slots) do
        if slot.entry then
            local total = 0
            for _, t in ipairs(slot.entry.transitions or {}) do
                total = total + Enc.prob_decode12(t.prob12)
            end
            if total > 1e-9 then
                for _, t in ipairs(slot.entry.transitions) do
                    local p = Enc.prob_decode12(t.prob12) / total
                    t.prob12 = Enc.prob_encode12(p)
                end
                fixed = fixed + 1
            end
        end
    end
    print(("[TC] Normalised %d states"):format(fixed))
end

-- Serialise state data array to binary string for file save
function TransitionCore:serialise_entry(e)
    -- state_n_flags byte
    local n_enc = math.min(5, math.max(0, (e.n or 1) - 2))  -- n=2→0, n=7→5
    local flags = n_enc & 0x07
    if e.terminal     then flags = flags | 0x08 end
    if e.has_extended then flags = flags | 0x10 end
    if e.pattern_root then flags = flags | 0x20 end

    local trans = e.transitions or {}
    local num_t = math.min(254, #trans)   -- inline cap 254, rest → extended

    local parts = {
        Enc.pack32(e.hash or 0),
        string.char(flags),
        Enc.varint_encode(e.count or 1),
        string.char(num_t),
    }
    for i = 1, num_t do
        parts[#parts+1] = TransitionCore.pack_transition(trans[i])
    end
    return table.concat(parts)
end

-- Save to file (simplified binary format)
function TransitionCore:save(path)
    local f = assert(io.open(path, "wb"))
    -- Collect all entries
    local all = {}
    for _, s in pairs(self.slots) do
        if s.entry then all[#all+1] = s.entry end
    end
    for _, e in pairs(self.staging) do all[#all+1] = e end

    -- File header
    local raw_size = self.n_entries * 48   -- approx
    f:write(Enc.file_header(MAGIC.CTC, #all, raw_size, raw_size))

    local block_data = {}
    local block_crc_interval = 4096

    for i, e in ipairs(all) do
        local s = self:serialise_entry(e)
        block_data[#block_data+1] = s
        -- Write CRC block every 4096 bytes
        local total = 0
        for _, bd in ipairs(block_data) do total = total + #bd end
        if total >= block_crc_interval then
            local chunk = table.concat(block_data)
            f:write(chunk)
            f:write(Enc.pack32(Enc.crc32(chunk)))
            block_data = {}
        end
    end
    if #block_data > 0 then
        local chunk = table.concat(block_data)
        f:write(chunk)
        f:write(Enc.pack32(Enc.crc32(chunk)))
    end
    f:close()
    print(("[TC] Saved %d states → %s"):format(#all, path))
end

function TransitionCore:load(path)
    local f = io.open(path, "rb")
    if not f then print("[TC] No file: "..path); return false end
    f:read(64)  -- skip header
    local raw = f:read("*a")
    f:close()
    -- Simple recovery: parse serialised entries
    local pos = 1
    local count = 0
    while pos <= #raw - 8 do
        local hash32 = Enc.unpack32(raw, pos); pos = pos + 4
        if hash32 == 0 then break end
        local flags  = string.byte(raw, pos); pos = pos + 1
        local cnt, np = Enc.varint_decode(raw, pos); pos = np
        local num_t  = string.byte(raw, pos); pos = pos + 1
        local trans  = {}
        for _ = 1, num_t do
            if pos + 4 <= #raw then
                local t, np2 = TransitionCore.unpack_transition(raw, pos)
                trans[#trans+1] = t
                pos = np2
            end
        end
        local entry = {
            hash = hash32, count = cnt, flags = flags,
            transitions = trans,
            terminal     = (flags & 0x08) ~= 0,
            has_extended = (flags & 0x10) ~= 0,
            pattern_root = (flags & 0x20) ~= 0,
            n = (flags & 0x07) + 2,
        }
        self:put(entry)
        count = count + 1
    end
    print(("[TC] Loaded %d states from %s"):format(count, path))
    return true
end

-- ────────────────────────────────────────────────────────────────
--  §3  COLD ARCHIVE  (disk-backed, bucket-indexed by hash prefix)
--  bucket_id = hash32 >> 16  → 65,536 buckets
--  Each bucket: sorted StateEntry list stored as simple text (Lua)
--  Real impl would LZ4 compress; here we use plain IO.
-- ────────────────────────────────────────────────────────────────

local ColdArchive = {}
ColdArchive.__index = ColdArchive

function ColdArchive.new(path, max_cold)
    local self   = setmetatable({}, ColdArchive)
    self.path    = path
    self.max_cold = max_cold or 10000000
    -- Bucket index: bucket_id → { offset, comp_size, entry_count }
    -- Loaded into memory (512 KB)
    self.bucket_index = {}   -- 65536 entries
    for i = 0, 65535 do
        self.bucket_index[i] = { offset=0, size=0, count=0 }
    end
    -- In-memory write buffer for each bucket
    self.write_buf = {}      -- bucket_id → list of StateEntry
    self.n_entries = 0
    -- Access counters for promotion (spec §7)
    self.access_count = {}   -- bucket_id → int
    self.promo_thresh = 10
    return self
end

-- Add a state to the cold archive write buffer
function ColdArchive:put(entry)
    local bucket = (entry.hash >> 16) & 0xFFFF
    if not self.write_buf[bucket] then self.write_buf[bucket] = {} end
    table.insert(self.write_buf[bucket], entry)
    self.n_entries = self.n_entries + 1
end

-- Lookup a state; returns entry or nil
function ColdArchive:get(hash32)
    local bucket = (hash32 >> 16) & 0xFFFF
    -- Try in-memory write buffer first
    if self.write_buf[bucket] then
        for _, e in ipairs(self.write_buf[bucket]) do
            if e.hash == hash32 then
                self:_track_access(bucket)
                return e
            end
        end
    end
    -- Read from disk
    local e = self:_disk_read(bucket, hash32)
    if e then self:_track_access(bucket) end
    return e
end

function ColdArchive:_track_access(bucket)
    self.access_count[bucket] = (self.access_count[bucket] or 0) + 1
    if self.access_count[bucket] >= self.promo_thresh then
        return true   -- caller should promote
    end
    return false
end

function ColdArchive:needs_promotion(bucket)
    return (self.access_count[bucket] or 0) >= self.promo_thresh
end

-- Disk I/O: each bucket stored as a line-delimited text chunk
-- Format: "hash32|n|count|num_trans|t1_target:t1_prob:t1_type|...\n"
function ColdArchive:_entry_to_line(e)
    local parts = { e.hash, e.n or 2, e.count or 1, #(e.transitions or {}) }
    for _, t in ipairs(e.transitions or {}) do
        parts[#parts+1] = t.target..":"..t.prob12..":"..t.ttype
    end
    return table.concat(parts, "|")
end

function ColdArchive:_line_to_entry(line)
    local p = {}
    for s in line:gmatch("[^|]+") do p[#p+1] = s end
    if #p < 4 then return nil end
    local hash32   = tonumber(p[1])
    local n        = tonumber(p[2])
    local count    = tonumber(p[3])
    local num_t    = tonumber(p[4])
    local trans = {}
    for i = 1, num_t do
        local tp = p[4+i]
        if tp then
            local t, pr, ty = tp:match("(%d+):(%d+):(%d+)")
            trans[#trans+1] = {
                target = tonumber(t),
                prob12 = tonumber(pr),
                prob   = Enc.prob_decode12(tonumber(pr) or 0),
                ttype  = tonumber(ty),
            }
        end
    end
    return { hash=hash32, n=n, count=count, transitions=trans }
end

function ColdArchive:_disk_read(bucket, target_hash)
    local idx = self.bucket_index[bucket]
    if not idx or idx.count == 0 then return nil end
    local f = io.open(self.path, "rb")
    if not f then return nil end
    f:seek("set", idx.offset)
    local chunk = f:read(idx.size)
    f:close()
    if not chunk then return nil end
    -- Binary search by hash (sorted within bucket)
    for line in (chunk.."\n"):gmatch("([^\n]*)\n") do
        if #line > 4 then
            local e = self:_line_to_entry(line)
            if e and e.hash == target_hash then return e end
        end
    end
    return nil
end

-- Flush all write buffers to disk
function ColdArchive:flush(path)
    path = path or self.path
    local f = assert(io.open(path, "wb"))
    -- File header
    f:write(Enc.file_header(MAGIC.CAR, self.n_entries, self.n_entries*44, self.n_entries*44))
    -- Reserve space for bucket index (65536 × 8 bytes = 512KB)
    local IDX_SIZE = 65536 * 8
    local idx_placeholder = string.rep("\0", IDX_SIZE)
    f:write(idx_placeholder)

    local offsets = {}

    for bucket = 0, 65535 do
        local entries = self.write_buf[bucket]
        if entries and #entries > 0 then
            -- Sort by hash for binary search
            table.sort(entries, function(a,b) return a.hash < b.hash end)
            local lines = {}
            for _, e in ipairs(entries) do
                lines[#lines+1] = self:_entry_to_line(e)
            end
            local chunk = table.concat(lines, "\n") .. "\n"
            local crc   = Enc.crc32(chunk)
            local offset = f:seek()
            f:write(chunk)
            f:write(Enc.pack32(crc))
            offsets[bucket] = { offset=offset, size=#chunk+4, count=#entries }
        end
    end

    -- Write bucket index at offset 64 (after file header)
    f:seek("set", 64)
    for b = 0, 65535 do
        local idx = offsets[b] or { offset=0, size=0, count=0 }
        f:write(Enc.pack32(idx.offset or 0))
        f:write(Enc.pack32(idx.size   or 0))   -- compressed_size (2B) + count (2B) packed as 4B
    end

    f:close()
    -- Update in-memory index
    for b, idx in pairs(offsets) do
        self.bucket_index[b] = idx
    end
    print(("[CA] Flushed %d cold states → %s"):format(self.n_entries, path))
end

function ColdArchive:load_index(path)
    path = path or self.path
    local f = io.open(path, "rb")
    if not f then return false end
    f:read(64)   -- skip file header
    for b = 0, 65535 do
        local raw = f:read(8)
        if not raw or #raw < 8 then break end
        local offset = Enc.unpack32(raw, 1)
        local sz_cnt = Enc.unpack32(raw, 5)
        self.bucket_index[b] = { offset=offset, size=sz_cnt, count=sz_cnt }
    end
    f:close()
    print("[CA] Index loaded from " .. path)
    return true
end

-- ────────────────────────────────────────────────────────────────
--  §4  CASE LIBRARY  (disk, block-compressed, time-sortable IDs)
-- ────────────────────────────────────────────────────────────────
--  case_id = timestamp_48 (ms) | sequence_16
--  Block size: 64KB raw → ~2112 cases/block → ~47K blocks for 100M

local CaseLibrary = {}
CaseLibrary.__index = CaseLibrary

function CaseLibrary.new(path, pattern_dict)
    local self     = setmetatable({}, CaseLibrary)
    self.path      = path
    self.pdict     = pattern_dict
    self.BLOCK_SIZE = 64 * 1024   -- 64 KB
    -- In-memory block index (0.7 MB for 47K blocks × 16 bytes)
    self.block_index = {}   -- list of { min_case_id, offset, comp_size, count }
    -- Write buffer (cases accumulate until one block)
    self.write_buf  = {}
    self.write_buf_size = 0
    self.n_cases    = 0
    self.total_blocks = 0
    -- Per-millisecond sequence counter
    self.last_ms    = 0
    self.seq        = 0
    return self
end

-- Generate a time-sortable case_id (spec §4)
function CaseLibrary:next_case_id()
    local ms = math.floor(os.time() * 1000)   -- Lua doesn't have ms precision; OK
    if ms == self.last_ms then
        self.seq = (self.seq + 1) % 65536
    else
        self.seq = 0
        self.last_ms = ms
    end
    -- case_id as two numbers: { hi=seq, lo=ms } (simplified, stored as string key)
    return ms * 65536 + self.seq
end

-- Serialise a CaseEntry
function CaseLibrary:_serialise_case(c)
    local cid = c.case_id or self:next_case_id()
    local chain_pattern = c.pattern_id or 0

    local parts = {
        -- 8-byte case_id (as two 4B values)
        Enc.pack32(cid & 0xFFFFFFFF),
        Enc.pack32((cid >> 32) & 0xFFFFFFFF),
        Enc.pack32(c.entry_state  or 0),   -- entry state hash
        string.char(c.chain_length or 1),
        string.char(chain_pattern & 0xFF),
        string.char((chain_pattern >> 8) & 0xFF),
    }

    if chain_pattern == 0 then
        -- Variant A: custom chain (4 bytes per state hash)
        local chain = c.custom_chain or {}
        for _, h in ipairs(chain) do
            parts[#parts+1] = Enc.pack32(h)
        end
    else
        -- Variant B: pattern + slot values
        local slots = c.slot_values or {}
        parts[#parts+1] = string.char(#slots)
        -- Simplified msgpack: length-prefixed strings
        for _, sv in ipairs(slots) do
            local s = tostring(sv)
            parts[#parts+1] = string.char(math.min(255,#s)) .. s:sub(1,255)
        end
    end

    -- Metadata: success_rate_u8 + usage_count_u32
    parts[#parts+1] = string.char(math.floor((c.success_rate or 0.5) * 255))
    parts[#parts+1] = Enc.pack32(c.usage_count or 0)

    return table.concat(parts)
end

-- Add a case; buffer until block is full, then flush block
function CaseLibrary:add(c)
    c.case_id = c.case_id or self:next_case_id()
    local s   = self:_serialise_case(c)
    self.write_buf[#self.write_buf+1] = s
    self.write_buf_size = self.write_buf_size + #s
    self.n_cases = self.n_cases + 1

    if self.write_buf_size >= self.BLOCK_SIZE then
        self:_flush_block()
    end
    return c.case_id
end

function CaseLibrary:_flush_block()
    if #self.write_buf == 0 then return end
    local raw   = table.concat(self.write_buf)
    local crc   = Enc.pack32(Enc.crc32(raw))
    -- In a real impl: zstd compress raw here.
    -- For CPU Lua: store raw + CRC (no external compressor available inline)
    local block_data = raw .. crc

    local f = io.open(self.path, "ab")
    if not f then
        -- First time: create file with header
        f = assert(io.open(self.path, "wb"))
        f:write(Enc.file_header(MAGIC.CCL, 0, 0, 0))
    end

    local offset = f:seek("end") or 0
    f:write(block_data)
    f:close()

    -- Update block index (in memory)
    self.block_index[#self.block_index+1] = {
        min_case_id = 0,   -- simplified
        offset      = offset,
        comp_size   = #block_data,
        count       = #self.write_buf,
    }
    self.total_blocks = self.total_blocks + 1
    self.write_buf      = {}
    self.write_buf_size = 0
end

function CaseLibrary:finalise()
    self:_flush_block()
    -- Save block index as a sidecar file
    local idx_path = self.path .. ".idx"
    local f = assert(io.open(idx_path, "wb"))
    f:write(Enc.pack32(#self.block_index))
    for _, blk in ipairs(self.block_index) do
        f:write(Enc.pack32(blk.offset))
        f:write(Enc.pack32(blk.comp_size))
        f:write(Enc.pack32(blk.count))
    end
    f:close()
    print(("[CL] %d cases in %d blocks → %s"):format(
          self.n_cases, self.total_blocks, self.path))
end

function CaseLibrary:load_index()
    local idx_path = self.path .. ".idx"
    local f = io.open(idx_path, "rb")
    if not f then return false end
    local n_raw = f:read(4)
    if not n_raw then f:close(); return false end
    local n = Enc.unpack32(n_raw)
    for _ = 1, n do
        local raw = f:read(12)
        if not raw or #raw < 12 then break end
        self.block_index[#self.block_index+1] = {
            offset    = Enc.unpack32(raw, 1),
            comp_size = Enc.unpack32(raw, 5),
            count     = Enc.unpack32(raw, 9),
        }
    end
    f:close()
    self.total_blocks = #self.block_index
    print(("[CL] Index: %d blocks loaded"):format(self.total_blocks))
    return true
end

-- ────────────────────────────────────────────────────────────────
--  §5  PATTERN DICTIONARY  (5 MB memory, 10K patterns)
--  PatternEntry: pattern_id, sequence, slots, template_hash,
--                usage_stats, description
--  Slot sentinel: 0xFFFF0000 | slot_index
-- ────────────────────────────────────────────────────────────────

local SLOT_SENTINEL = 0xFFFF0000

local PatternDict = {}
PatternDict.__index = PatternDict

-- SlotDef type constants
local SLOT_TYPE = { STRING=0, NUMBER=1, BOOLEAN=2, DATE=3, ENUM=4 }

function PatternDict.new()
    local self      = setmetatable({}, PatternDict)
    self.patterns   = {}        -- pattern_id → PatternEntry
    self.by_template= {}        -- template_hash → list of pattern_ids
    self.next_id    = 1
    self.n_patterns = 0
    return self
end

-- Add a pattern from a state sequence with slot positions marked
-- sequence: list of hash32 values (0xFFFF0000|i for slots)
-- slot_defs: list of { type, max_length }
function PatternDict:add_pattern(sequence, slot_defs, description)
    if self.n_patterns >= 10000 then
        print("[PD] WARNING: pattern limit reached (10K)")
        return nil
    end
    local pid = self.next_id
    self.next_id = self.next_id + 1

    -- Compute template_hash (hash the sequence with slots as type markers)
    local template_str = {}
    for _, h in ipairs(sequence) do
        if (h & 0xFFFF0000) == SLOT_SENTINEL then
            local slot_idx = h & 0xFFFF
            local stype = slot_defs[slot_idx+1] and slot_defs[slot_idx+1].type or 0
            template_str[#template_str+1] = "SLOT:" .. stype
        else
            template_str[#template_str+1] = tostring(h)
        end
    end
    local template_hash = Enc.fnv1a32(table.concat(template_str, "|"))

    local entry = {
        pattern_id     = pid,
        sequence_length = #sequence,
        state_sequence = sequence,
        slot_count     = slot_defs and #slot_defs or 0,
        slot_defs      = slot_defs or {},
        template_hash  = template_hash,
        frequency      = 0,
        last_used      = os.time(),
        description    = description or ("pattern_"..pid),
    }

    self.patterns[pid] = entry
    if not self.by_template[template_hash] then
        self.by_template[template_hash] = {}
    end
    table.insert(self.by_template[template_hash], pid)
    self.n_patterns = self.n_patterns + 1

    return pid
end

-- Match a state chain against known patterns
-- Returns: pattern_id, slot_values (extracted) or nil
function PatternDict:match(state_chain)
    if #state_chain < 2 then return nil, nil end

    -- Compute template hash of the input chain
    -- (first pass: all non-fixed values treated as wildcard)
    local L = #state_chain

    for _, pid_list in pairs(self.by_template) do
        for _, pid in ipairs(pid_list) do
            local p = self.patterns[pid]
            if p and p.sequence_length == L then
                -- Try to match
                local slot_values = {}
                local matched = true

                for i, ph in ipairs(p.state_sequence) do
                    local ch = state_chain[i]
                    if (ph & 0xFFFF0000) == SLOT_SENTINEL then
                        -- Variable slot: extract value
                        local si = (ph & 0xFFFF) + 1
                        slot_values[si] = ch
                    elseif ph ~= ch then
                        matched = false
                        break
                    end
                end

                if matched then
                    p.frequency = p.frequency + 1
                    p.last_used = os.time()
                    return pid, slot_values
                end
            end
        end
    end
    return nil, nil
end

-- Expand a pattern with slot values → full state chain
function PatternDict:expand(pid, slot_values)
    local p = self.patterns[pid]
    if not p then return nil end
    local chain = {}
    for _, ph in ipairs(p.state_sequence) do
        if (ph & 0xFFFF0000) == SLOT_SENTINEL then
            local si = (ph & 0xFFFF) + 1
            chain[#chain+1] = slot_values[si] or 0
        else
            chain[#chain+1] = ph
        end
    end
    return chain
end

-- LRU eviction by frequency × recency
function PatternDict:maybe_evict()
    if self.n_patterns < 10000 then return end
    local worst_id, worst_score = nil, math.huge
    for pid, p in pairs(self.patterns) do
        local age   = os.time() - p.last_used
        local score = (p.frequency + 0.01) / (1 + age * 0.001)
        if score < worst_score then
            worst_score = score
            worst_id    = pid
        end
    end
    if worst_id then
        local p = self.patterns[worst_id]
        -- Remove from by_template
        local th = p.template_hash
        if self.by_template[th] then
            for i, id in ipairs(self.by_template[th]) do
                if id == worst_id then
                    table.remove(self.by_template[th], i)
                    break
                end
            end
        end
        self.patterns[worst_id] = nil
        self.n_patterns = self.n_patterns - 1
    end
end

function PatternDict:save(path)
    local f = assert(io.open(path, "wb"))
    f:write(Enc.file_header(MAGIC.PDT, self.n_patterns, self.n_patterns*500, self.n_patterns*500))
    for pid, p in pairs(self.patterns) do
        local seq_str = table.concat(p.state_sequence, ",")
        local slots_str = ""
        for _, sd in ipairs(p.slot_defs) do
            slots_str = slots_str .. sd.type .. ":" .. (sd.max_length or 255) .. ";"
        end
        local line = ("%d|%d|%s|%d|%s|%d|%d|%s\n"):format(
            pid, p.sequence_length, seq_str, p.slot_count,
            slots_str, p.frequency, p.last_used, p.description)
        f:write(line)
    end
    f:close()
    print(("[PD] Saved %d patterns → %s"):format(self.n_patterns, path))
end

function PatternDict:load(path)
    local f = io.open(path, "rb")
    if not f then return false end
    f:read(64)  -- skip header
    for line in f:lines() do
        local parts = {}
        for p in line:gmatch("[^|]+") do parts[#parts+1] = p end
        if #parts >= 7 then
            local pid   = tonumber(parts[1])
            local seq   = {}
            for v in parts[3]:gmatch("[^,]+") do seq[#seq+1]=tonumber(v) end
            local slots = {}
            for t, ml in parts[5]:gmatch("(%d+):(%d+);") do
                slots[#slots+1] = { type=tonumber(t), max_length=tonumber(ml) }
            end
            local entry = {
                pattern_id      = pid,
                sequence_length = tonumber(parts[2]),
                state_sequence  = seq,
                slot_count      = tonumber(parts[4]),
                slot_defs       = slots,
                frequency       = tonumber(parts[6]) or 0,
                last_used       = tonumber(parts[7]) or os.time(),
                description     = parts[8] or ("pattern_"..pid),
                template_hash   = 0,
            }
            -- Recompute template hash
            local template_str = {}
            for _, h in ipairs(seq) do
                if (h & 0xFFFF0000) == SLOT_SENTINEL then
                    local si = h & 0xFFFF
                    local stype = slots[si+1] and slots[si+1].type or 0
                    template_str[#template_str+1] = "SLOT:" .. stype
                else
                    template_str[#template_str+1] = tostring(h)
                end
            end
            entry.template_hash = Enc.fnv1a32(table.concat(template_str,"|"))
            self.patterns[pid] = entry
            if not self.by_template[entry.template_hash] then
                self.by_template[entry.template_hash] = {}
            end
            table.insert(self.by_template[entry.template_hash], pid)
            if pid >= self.next_id then self.next_id = pid + 1 end
            self.n_patterns = self.n_patterns + 1
        end
    end
    f:close()
    print(("[PD] Loaded %d patterns from %s"):format(self.n_patterns, path))
    return true
end

-- ────────────────────────────────────────────────────────────────
--  §6  UNIFIED STORE  (orchestrates all 5 components)
--  Implements the full lookup / write / promote / demote pipeline
-- ────────────────────────────────────────────────────────────────

local StateStore = {}
StateStore.__index = StateStore

function StateStore.new(cfg)
    local self = setmetatable({}, StateStore)
    cfg = cfg or {}
    self.save_dir  = cfg.save_dir or "./store"
    os.execute("mkdir -p " .. self.save_dir)

    -- Component init
    self.bloom   = BloomFilter.new(20000000, 10)    -- 20M states, 10 bits
    self.hot     = TransitionCore.new(10000000)     -- 10M hot states
    self.cold    = ColdArchive.new(
                       self.save_dir .. "/cold_archive.car", 10000000)
    self.pdict   = PatternDict.new()
    self.cases   = CaseLibrary.new(
                       self.save_dir .. "/case_library.ccl", self.pdict)

    -- Hot/cold thresholds (spec §7)
    self.promo_thresh = cfg.promo_thresh or 10   -- cold → hot
    self.demo_thresh  = cfg.demo_thresh  or 5    -- hot → cold
    self.demo_window  = cfg.demo_window  or 90   -- days

    -- Stats
    self.stats = {
        hot_hits=0, cold_hits=0, bloom_rejects=0,
        promotions=0, demotions=0, false_positives=0,
        cases_added=0, patterns_matched=0,
    }

    return self
end

-- ── LOOKUP  (spec §8 complete lookup pseudocode) ─────────────────
function StateStore:lookup(state_key)
    local hash32 = Enc.fnv1a32(state_key)

    -- Step 1: Bloom filter
    if not self.bloom:check(hash32) then
        self.stats.bloom_rejects = self.stats.bloom_rejects + 1
        return nil
    end

    -- Step 2: Hot table (MPHF approximated by open addressing)
    local entry = self.hot:get(hash32)
    if entry then
        self.stats.hot_hits = self.stats.hot_hits + 1
        return entry
    end

    -- Step 3: Cold archive (disk I/O)
    entry = self.cold:get(hash32)
    if entry then
        self.stats.cold_hits = self.stats.cold_hits + 1
        -- Check promotion eligibility
        local bucket = (hash32 >> 16) & 0xFFFF
        if self.cold:needs_promotion(bucket) then
            self:_promote(hash32, entry)
        end
        return entry
    end

    -- True miss (bloom false positive)
    self.stats.false_positives = self.stats.false_positives + 1
    return nil
end

-- ── WRITE  (insert new or update existing state) ─────────────────
function StateStore:record_transition(from_key, to_key, trans_type)
    local from_hash = Enc.fnv1a32(from_key)
    local to_hash   = Enc.fnv1a32(to_key)

    -- Ensure from-state exists in hot; if not, create it
    local entry = self.hot:get(from_hash)
    if not entry then
        entry = {
            hash = from_hash, n = 2, count = 0,
            transitions = {}, terminal = false,
            has_extended = false, pattern_root = false,
        }
    end
    entry.count = entry.count + 1

    -- Find or update transition to to_hash
    local to_idx = self.hot.n_entries   -- placeholder index
    local found  = false
    for _, t in ipairs(entry.transitions) do
        if t.target == (to_hash % 0x1000000) then   -- 24-bit target
            -- Increase probability weight
            local p = Enc.prob_decode12(t.prob12)
            t.prob12 = Enc.prob_encode12(math.min(1, p * 1.1 + 0.01))
            found = true; break
        end
    end
    if not found then
        entry.transitions[#entry.transitions+1] = {
            target = to_hash % 0x1000000,
            prob12 = Enc.prob_encode12(0.1),
            ttype  = trans_type or TRANS_TYPE.DIRECT,
        }
    end

    -- Update bloom
    self.bloom:add(from_hash)

    -- Decide hot vs cold based on count
    if entry.count >= self.promo_thresh then
        self.hot:put(entry)
    else
        self.cold:put(entry)
    end
end

-- ── CASE RECORDING ────────────────────────────────────────────────
function StateStore:record_case(query, response, state_chain, success_rate)
    -- Try pattern match first (90% savings)
    local pattern_id, slot_values = self.pdict:match(state_chain)
    local c

    if pattern_id then
        self.stats.patterns_matched = self.stats.patterns_matched + 1
        c = {
            entry_state   = state_chain[1],
            chain_length  = #state_chain,
            pattern_id    = pattern_id,
            slot_values   = slot_values,
            success_rate  = success_rate or 0.5,
            usage_count   = 0,
            query         = query,
            response      = response,
        }
    else
        -- Custom chain
        c = {
            entry_state   = state_chain[1],
            chain_length  = #state_chain,
            pattern_id    = 0,
            custom_chain  = state_chain,
            success_rate  = success_rate or 0.5,
            usage_count   = 0,
            query         = query,
            response      = response,
        }
    end

    local cid = self.cases:add(c)
    self.stats.cases_added = self.stats.cases_added + 1
    return cid
end

-- ── PROMOTION: cold → hot ─────────────────────────────────────────
function StateStore:_promote(hash32, entry)
    if self.hot.n_entries >= self.hot.max_hot * 1.1 then
        -- Hot table near capacity; trigger emergency demotion first
        self:_emergency_demote()
    end
    entry.count = (entry.count or 0) + self.promo_thresh
    self.hot:put(entry)
    self.stats.promotions = self.stats.promotions + 1
end

-- Emergency demotion: remove lowest-count hot states to cold
function StateStore:_emergency_demote()
    local candidates = {}
    for _, slot in pairs(self.hot.slots) do
        if slot.entry then
            candidates[#candidates+1] = { hash=slot.hash, count=slot.entry.count or 1 }
        end
    end
    table.sort(candidates, function(a,b) return a.count < b.count end)
    local demoted = 0
    for i = 1, math.min(100000, #candidates) do
        local c = candidates[i]
        if c.count < self.demo_thresh then
            local entry = self.hot:get(c.hash)
            if entry then
                self.cold:put(entry)
                -- Remove from hot (mark slot as nil)
                local slot, found = self.hot:_find_slot(c.hash)
                if found then self.hot.slots[slot] = nil end
            end
            demoted = demoted + 1
        end
    end
    self.stats.demotions = self.stats.demotions + demoted
    print(("[Store] Emergency demotion: %d states moved to cold"):format(demoted))
end

-- ── STATS ─────────────────────────────────────────────────────────
function StateStore:print_stats()
    local s = self.stats
    print("┌─── StateStore Stats ─────────────────────────────┐")
    print(("│  Hot hits:         %10d"):format(s.hot_hits))
    print(("│  Cold hits:        %10d"):format(s.cold_hits))
    print(("│  Bloom rejects:    %10d"):format(s.bloom_rejects))
    print(("│  False positives:  %10d"):format(s.false_positives))
    print(("│  Promotions:       %10d"):format(s.promotions))
    print(("│  Demotions:        %10d"):format(s.demotions))
    print(("│  Cases added:      %10d"):format(s.cases_added))
    print(("│  Pattern matches:  %10d"):format(s.patterns_matched))
    print(("│  Bloom FPR:           %.3f%%"):format(self.bloom:fpr()*100))
    print(("│  Hot states:       %10d"):format(self.hot.n_entries))
    print(("│  Cold states:      %10d"):format(self.cold.n_entries))
    print(("│  Patterns:         %10d"):format(self.pdict.n_patterns))
    print("└──────────────────────────────────────────────────┘")
end

-- ── SAVE / LOAD ───────────────────────────────────────────────────
function StateStore:save()
    self.bloom:save(self.save_dir .. "/bloom.blf")
    self.hot:save(  self.save_dir .. "/transition_core.ctc")
    self.cold:flush(self.save_dir .. "/cold_archive.car")
    self.pdict:save(self.save_dir .. "/pattern_dict.pdt")
    self.cases:finalise()
    self:print_stats()
end

function StateStore:load()
    self.bloom:load(    self.save_dir .. "/bloom.blf")
    self.hot:load(      self.save_dir .. "/transition_core.ctc")
    self.cold:load_index(self.save_dir .. "/cold_archive.car")
    self.pdict:load(    self.save_dir .. "/pattern_dict.pdt")
    self.cases:load_index()
end

-- ────────────────────────────────────────────────────────────────
--  EXPORTS
-- ────────────────────────────────────────────────────────────────

return {
    StateStore     = StateStore,
    BloomFilter    = BloomFilter,
    TransitionCore = TransitionCore,
    ColdArchive    = ColdArchive,
    PatternDict    = PatternDict,
    CaseLibrary    = CaseLibrary,
    Enc            = Enc,
    TRANS_TYPE     = TRANS_TYPE,
    SLOT_TYPE      = SLOT_TYPE,
    SLOT_SENTINEL  = SLOT_SENTINEL,
    MAGIC          = MAGIC,
}
