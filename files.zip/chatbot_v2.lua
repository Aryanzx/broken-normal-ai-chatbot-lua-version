-- ================================================================
--  chatbot_v2.lua  ─  SSM + Engram v2 + CBR v2 + StateStore
--                     Full USTCC Architecture Chatbot
--
--  Per-turn pipeline:
--    1. Tokenise input
--    2. Bloom filter: fast-reject unknown state signatures
--    3. TransitionCore: lookup hot state transitions → TC-guided beam
--    4. Engram v2: retrieve N-gram memory (multi-branch, conv-refined)
--    5. SSM v2: selective scan with TC-conditioned Δ scaling
--    6. CBR v2: check Case Library + Pattern Dictionary
--    7. Smart decode: Pattern early-exit OR TC-guided beam search
--    8. Markov RL: Bellman update → TC transitions + Engram Hebbian
--    9. RETAIN: new case stored in CaseLibrary (block-compressed)
-- ================================================================

local SS  = require("state_store")
local Eng = require("engram_v2")
local SSM = require("ssm_v2")
local CBR = require("cbr_v2")

-- ────────────────────────────────────────────────────────────────
--  Tokeniser (word-level + punctuation split)
-- ────────────────────────────────────────────────────────────────

local Tokenizer = {}
Tokenizer.__index = Tokenizer

function Tokenizer.new()
    local self = setmetatable({}, Tokenizer)
    self.word2id = {["<pad>"]=1,["<unk>"]=2,["<bos>"]=3,["<eos>"]=4}
    self.id2word = {[1]="<pad>",[2]="<unk>",[3]="<bos>",[4]="<eos>"}
    self.next_id = 5
    return self
end

function Tokenizer:add(w)
    if not self.word2id[w] then
        self.word2id[w]         = self.next_id
        self.id2word[self.next_id] = w
        self.next_id = self.next_id + 1
    end
    return self.word2id[w]
end

function Tokenizer:encode(text)
    local ids, toks = {}, {}
    local s = text:lower():gsub("([%.%,!%?;:])", " %1 ")
    for w in s:gmatch("%S+") do
        local id = self.word2id[w] or self:add(w)
        ids[#ids+1]=id; toks[#toks+1]=w
    end
    return ids, toks
end

function Tokenizer:decode(ids)
    local ws={}
    for _,id in ipairs(ids) do ws[#ws+1]=self.id2word[id] or "<unk>" end
    return table.concat(ws," "):gsub(" ([%.%,!%?;:])","%1")
end

function Tokenizer:save(path)
    local f=assert(io.open(path,"w"))
    for w,id in pairs(self.word2id) do
        f:write(id.."|"..w:gsub("|","\\p").."\n")
    end
    f:close()
end

function Tokenizer:load(path)
    local f=io.open(path,"r"); if not f then return false end
    for line in f:lines() do
        local id,w=line:match("^(%d+)|(.+)$")
        if id then
            w=w:gsub("\\p","|"); id=tonumber(id)
            self.word2id[w]=id; self.id2word[id]=w
            if id>=self.next_id then self.next_id=id+1 end
        end
    end
    f:close(); return true
end

-- ────────────────────────────────────────────────────────────────
--  Chatbot v2
-- ────────────────────────────────────────────────────────────────

local Chatbot = {}
Chatbot.__index = Chatbot

function Chatbot.new(cfg)
    local self = setmetatable({}, Chatbot)
    cfg = cfg or {}

    self.save_dir   = cfg.save_dir or "./checkpoints_v2"
    self.verbose    = cfg.verbose ~= false
    self.dim        = cfg.dim     or 128

    os.execute("mkdir -p " .. self.save_dir)

    -- ── 1. StateStore (USTCC core) ─────────────────────────────
    self.store = SS.StateStore.new({
        save_dir     = self.save_dir .. "/store",
        promo_thresh = cfg.promo_thresh or 10,
        demo_thresh  = cfg.demo_thresh  or 5,
    })

    -- ── 2. Tokeniser ───────────────────────────────────────────
    self.tokenizer = Tokenizer.new()

    -- ── 3. Engram v2 ───────────────────────────────────────────
    self.engram = Eng.new({
        dim        = self.dim,
        max_ngram  = cfg.max_ngram  or 3,
        vocab_size = cfg.vocab_size or 50000,
        lr         = cfg.engram_lr  or 0.005,
        n_branches = cfg.n_branches or 4,
        store      = self.store,
    })

    -- ── 4. SSM v2 ──────────────────────────────────────────────
    self.model = SSM.new({
        d           = self.dim,
        N           = cfg.ssm_state  or 32,
        n_layers    = cfg.n_layers   or 4,
        vocab_size  = cfg.vocab_size or 50000,
        max_context = cfg.max_context or 64,
    }, self.engram, self.store)

    -- ── 5. CBR v2 ──────────────────────────────────────────────
    self.cbr = CBR.new({
        dim             = self.dim,
        sim_thresh      = cfg.sim_thresh or 0.60,
        epsilon         = cfg.epsilon    or 0.15,
        gamma           = cfg.gamma      or 0.90,
        lr_q            = cfg.lr_q       or 0.10,
        n_state_buckets = cfg.n_state_buckets or 128,
        max_cases       = cfg.max_cases  or 5000,
        store           = self.store,
    })

    -- Conversation history
    self.history = {}
    self.turn    = 0

    return self
end

-- ────────────────────────────────────────────────────────────────
--  Main turn handler
-- ────────────────────────────────────────────────────────────────

function Chatbot:respond(user_text)
    self.turn = self.turn + 1

    -- 1. Tokenise
    local ids, toks = self.tokenizer:encode(user_text)

    -- 2. Feed through SSM to get hidden representation
    self.model:reset()
    local last_h
    for i,pid in ipairs(ids) do
        local _, h = self.model:forward_step(toks[i], pid)
        last_h = h
    end
    last_h = last_h or {}

    -- 3. Bloom pre-filter: check if user query pattern is known
    local q_hash = SS.Enc.fnv1a32(user_text:lower():sub(1,64))
    local bloom_known = self.store.bloom:check(q_hash)

    -- 4. CBR fast-path (known case retrieval)
    local response_text, q_emb, cbr_sim
    local used_cbr = false

    if bloom_known then
        response_text, q_emb, cbr_sim = self.cbr:query(user_text, last_h)
        if response_text and cbr_sim > self.cbr.sim_thresh then
            used_cbr = true
            if self.verbose then
                print(("[CBR] Hit sim=%.2f: %s"):format(cbr_sim, response_text:sub(1,50)))
            end
        else
            response_text = nil
        end
    end

    -- 5. SSM smart decode (fallback)
    local response_ids, response_toks
    if not response_text then
        response_ids, response_toks, last_h = self.model:smart_decode(
            ids, toks, self.tokenizer, {
                max_gen     = 60,
                beam_width  = 3,
                temperature = 0.8,
                top_k       = 40,
            })
        response_text = self.tokenizer:decode(response_ids)
        if self.verbose then
            print("[SSM] Gen: " .. response_text:sub(1,60))
        end
    end

    -- 6. Record turn in StateStore
    local state_chain = {}
    for _, t in ipairs(toks) do
        state_chain[#state_chain+1] = SS.Enc.fnv1a32(t)
    end
    -- Transitions: each token → next
    for i=2,#toks do
        self.store:record_transition("tok_"..toks[i-1], "tok_"..toks[i])
    end
    -- Add query to bloom
    self.store.bloom:add(q_hash)

    -- 7. Engram: record sequence for future N-gram retrieval
    self.engram:record_sequence(toks, response_text, 0.5)

    -- 8. Store turn in history
    local entry = {
        role      = "assistant",
        text      = response_text,
        q_text    = user_text,
        q_emb     = q_emb,
        hidden    = last_h,
        used_cbr  = used_cbr,
        cbr_sim   = cbr_sim,
        state_chain = state_chain,
        turn      = self.turn,
    }
    table.insert(self.history, entry)

    return response_text, entry
end

-- ────────────────────────────────────────────────────────────────
--  Feedback & RL Update
--  reward: +1 (good), 0 (neutral), -1 (bad)
-- ────────────────────────────────────────────────────────────────

function Chatbot:feedback(reward)
    local entry = self.history[#self.history]
    if not entry then return end

    -- Markov Q-learning (CBR RL)
    self.cbr:rl_update(reward, entry.hidden)

    -- Engram Hebbian update
    if entry.hidden and #entry.hidden > 0 then
        self.engram:update(
            entry.q_text:lower():gmatch("%S+") and (function()
                local t={}; for w in entry.q_text:lower():gmatch("%S+") do t[#t+1]=w end
                return t
            end)() or {},
            entry.hidden,
            reward
        )
    end

    -- CBR retain: only for positive reward
    if reward > 0 then
        self.cbr:retain(
            entry.q_text, entry.text,
            entry.q_emb, entry.state_chain, 0.8)
    end

    -- Update transition success signal in StateStore
    if entry.state_chain and #entry.state_chain >= 2 then
        for i=1,#entry.state_chain-1 do
            local fk = "tok_" .. tostring(entry.state_chain[i])
            local tk = "tok_" .. tostring(entry.state_chain[i+1])
            local trans_type = reward >= 0 and SS.TRANS_TYPE.DIRECT
                                           or  SS.TRANS_TYPE.DECAY
            self.store:record_transition(fk, tk, trans_type)
        end
    end

    if self.verbose then
        print(("[RL] r=%.1f  CBR=%d  Bloom_FPR=%.2f%%"):format(
            reward, self.cbr.n_cases, self.store.bloom:fpr()*100))
    end
end

-- ────────────────────────────────────────────────────────────────
--  Knowledge loading
-- ────────────────────────────────────────────────────────────────

function Chatbot:load_knowledge(path)
    local count = self.cbr:load_knowledge(path)
    -- Also tokenise for vocabulary
    local f = io.open(path, "r")
    if f then
        for line in f:lines() do
            local q = line:match('"input"%s*:%s*"(.-)"')
                   or line:match('"question"%s*:%s*"(.-)"')
                   or line:match('"prompt"%s*:%s*"(.-)"')
            local r = line:match('"output"%s*:%s*"(.-)"')
                   or line:match('"answer"%s*:%s*"(.-)"')
            if q then self.tokenizer:encode(q) end
            if r then self.tokenizer:encode(r) end
        end
        f:close()
    end
    return count
end

-- ────────────────────────────────────────────────────────────────
--  Save / Load
-- ────────────────────────────────────────────────────────────────

function Chatbot:save()
    self.store:save()
    self.engram:save(   self.save_dir .. "/engram_v2.dat")
    self.model:save(    self.save_dir .. "/ssm_v2.dat")
    self.cbr:save(      self.save_dir .. "/cbr_v2.dat")
    self.tokenizer:save(self.save_dir .. "/vocab.dat")
    print("[Chatbot v2] All components saved to " .. self.save_dir)
end

function Chatbot:load()
    self.store:load()
    self.engram:load(   self.save_dir .. "/engram_v2.dat")
    self.model:load(    self.save_dir .. "/ssm_v2.dat")
    self.cbr:load(      self.save_dir .. "/cbr_v2.dat")
    self.tokenizer:load(self.save_dir .. "/vocab.dat")
    print("[Chatbot v2] All components loaded")
end

-- ────────────────────────────────────────────────────────────────
--  Stats display
-- ────────────────────────────────────────────────────────────────

function Chatbot:stats()
    self.store:print_stats()
    self.engram:print_stats()
    print(("CBR cases=%d  Q-entries=%d  Patterns=%d"):format(
        self.cbr.n_cases,
        (function() local n=0; for _,r in pairs(self.cbr.Q) do
            for _ in pairs(r) do n=n+1 end end; return n end)(),
        self.store.pdict.n_patterns))
end

-- ────────────────────────────────────────────────────────────────
--  Interactive REPL
-- ────────────────────────────────────────────────────────────────

function Chatbot:repl()
    print("╔═══════════════════════════════════════════════════════╗")
    print("║   SSM + Engram v2 + CBR v2 + StateStore Chatbot       ║")
    print("║   USTCC Architecture v2.0  (10M hot / 100M cases)     ║")
    print("╠═══════════════════════════════════════════════════════╣")
    print("║  /good  /bad  /save  /stats  /load <path>  quit       ║")
    print("╚═══════════════════════════════════════════════════════╝")

    while true do
        io.write("\nYou: ")
        local line = io.read()
        if not line or line:lower() == "quit" then
            print("Saving before exit …"); self:save(); break

        elseif line:sub(1,5) == "/good" then
            self:feedback(1.0); print("[RL] +1 recorded")
        elseif line:sub(1,4) == "/bad" then
            self:feedback(-1.0); print("[RL] -1 recorded")
        elseif line:sub(1,5) == "/save" then
            self:save()
        elseif line:sub(1,6) == "/stats" then
            self:stats()
        elseif line:sub(1,5) == "/load" then
            local p = line:match("/load%s+(.+)")
            if p then self:load_knowledge(p:gsub('"',''))
            else print("Usage: /load <path.jsonl>") end
        elseif line:sub(1,6) == "/mine" then
            self.cbr:mine_patterns(3)
        elseif #line:gsub("%s","") > 0 then
            local reply = self:respond(line)
            print("Bot: " .. reply)
        end
    end
end

-- ────────────────────────────────────────────────────────────────
--  Entry point
-- ────────────────────────────────────────────────────────────────

local bot = Chatbot.new({
    dim           = 128,
    ssm_state     = 32,
    n_layers      = 4,
    max_ngram     = 3,
    n_branches    = 4,       -- multi-branch Engram (§2.4)
    vocab_size    = 50000,
    max_cases     = 5000,
    sim_thresh    = 0.60,
    epsilon       = 0.15,
    gamma         = 0.90,
    n_state_buckets = 128,
    promo_thresh  = 10,       -- cold → hot (spec §7)
    demo_thresh   = 5,        -- hot → cold
    save_dir      = "./checkpoints_v2",
    verbose       = true,
})

bot:load()

local arg = arg or {}
if arg[1] then bot:load_knowledge(arg[1]) end

bot:repl()
