"""
train_colab_v2.py  ─  USTCC-Aware SSM Chatbot Trainer
================================================================
Implements the full USTCC architecture in PyTorch for training,
then exports binary checkpoints compatible with Lua chatbot_v2.

Architecture mirrors the spec:
  • TransitionCore: learned transition probabilities (12-bit log-scale)
  • EngramLayer v2: multi-branch gating (paper §2.4), depthwise conv
  • SSM blocks: Mamba-style selective scan, TC-conditioned Δ
  • MoE FFN: 8 experts, top-2 sparse routing
  • PatternDict: slot-template compression (exported as pattern_dict.pdt)
  • CaseLibrary: RL-selected QA pairs (exported as cbr_v2.dat)
  • MarkovRL: Bellman Q-learning over dataset BEFORE training

Data ingestion:
  • HuggingFace datasets (JSON / JSONL natively)
  • CSV → pandas clean → HuggingFace Dataset
  • Supports any input_col / output_col / text_col naming

TPU training via torch_xla; falls back to GPU/CPU automatically.

Usage in Colab:
    !pip install datasets transformers torch_xla pandas torch -q
    !python train_colab_v2.py \\
        --dataset daily_dialog \\
        --epochs 3 \\
        --d_model 128 \\
        --output_dir ./out_v2
================================================================
"""

import os, sys, json, math, argparse, random, time, struct
from pathlib import Path
from collections import defaultdict
import torch
import torch.nn as nn
import torch.nn.functional as F

# ── TPU ──────────────────────────────────────────────────────────
try:
    import torch_xla.core.xla_model as xm
    import torch_xla.distributed.parallel_loader as pl
    TPU_AVAILABLE = True
    print("✓ TPU (torch_xla) detected")
except ImportError:
    TPU_AVAILABLE = False

# ── HuggingFace ───────────────────────────────────────────────────
from datasets import Dataset, load_dataset
import pandas as pd

###############################################################################
#  ENCODING HELPERS  (mirrors state_store.lua §A)
###############################################################################

def fnv1a32(s: str | bytes) -> int:
    if isinstance(s, str):
        s = s.encode()
    h = 2166136261
    for b in s:
        h = ((h ^ b) * 16777619) & 0xFFFFFFFF
    return h

def prob_encode12(p: float) -> int:
    """Log-scale 12-bit probability encoding (spec §3)."""
    if p <= 0: return 4095
    if p >= 1: return 0
    return min(4095, max(0, round(-math.log2(p) * 256)))

def prob_decode12(v: int) -> float:
    if v == 0:    return 1.0
    if v == 4095: return 0.0
    return 2 ** (-v / 256)

def pack_le(value: int, n_bytes: int) -> bytes:
    return value.to_bytes(n_bytes, 'little', signed=False)

###############################################################################
#  DATA LOADING
###############################################################################

def _best_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None

def _normalise_ds(ds, text_col, input_col, output_col):
    cols = ds.column_names
    if "text" in cols:
        return ds
    ic = next((c for c in [input_col,"input","question","prompt","instruction"] if c in cols), None)
    oc = next((c for c in [output_col,"output","answer","response","completion"] if c in cols), None)
    tc = next((c for c in [text_col,"text","content","body"] if c in cols), None)
    if ic and oc:
        def merge(r): return {"text": f"Human: {r[ic]}\nAssistant: {r[oc]}"}
        return ds.map(merge, remove_columns=cols)
    elif tc:
        return ds.rename_column(tc, "text")
    def concat_all(r):
        return {"text": " ".join(str(v) for v in r.values() if isinstance(v,str) and v)}
    return ds.map(concat_all, remove_columns=cols)

def load_data(source, split="train", text_col="text", input_col="input", output_col="output"):
    p = Path(source)
    if p.suffix.lower() == ".csv":
        print(f"📂 CSV → pandas cleaning…")
        df = pd.read_csv(source, low_memory=False)
        df = df.dropna(how="all").drop_duplicates()
        df.columns = df.columns.str.strip().str.lower()
        for c in df.select_dtypes(include="object").columns:
            df[c] = df[c].str.strip()
        df = df.fillna("")
        ic = _best_col(df, [input_col,"input","question","prompt","instruction"])
        oc = _best_col(df, [output_col,"output","answer","response"])
        tc = _best_col(df, [text_col,"text","content","body"])
        if ic and oc and ic != oc:
            df["text"] = "Human: " + df[ic] + "\nAssistant: " + df[oc]
        elif tc:
            df = df.rename(columns={tc:"text"})
        else:
            raise ValueError(f"Cannot find text columns. Got: {list(df.columns)}")
        ds = Dataset.from_pandas(df[["text"]].dropna().reset_index(drop=True))
        print(f"  → {len(ds)} rows after cleaning")
        return ds
    elif p.suffix.lower() in (".json", ".jsonl"):
        ds = load_dataset("json", data_files=str(source), split="train")
    else:
        print(f"🤗 HuggingFace hub: {source}")
        ds = load_dataset(source, split=split, trust_remote_code=True)
    return _normalise_ds(ds, text_col, input_col, output_col)

###############################################################################
#  TOKENISER
###############################################################################

class SimpleTokenizer:
    SPECIAL = ["<pad>","<unk>","<bos>","<eos>"]
    def __init__(self, vocab_size=50000):
        self.vocab_size = vocab_size
        self.w2i = {w:i for i,w in enumerate(self.SPECIAL)}
        self.i2w = {i:w for w,i in self.w2i.items()}
        self.next_id = len(self.SPECIAL)
    def add(self, w):
        if w not in self.w2i and self.next_id < self.vocab_size:
            self.w2i[w] = self.next_id
            self.i2w[self.next_id] = w
            self.next_id += 1
        return self.w2i.get(w, 1)
    def encode(self, text, max_len=512):
        toks = text.lower().split()[:max_len]
        return [self.add(t) for t in toks], toks
    def decode(self, ids):
        return " ".join(self.i2w.get(i,"<unk>") for i in ids)
    def __len__(self): return self.next_id
    def save(self, path):
        with open(path,"w") as f:
            for w,i in self.w2i.items():
                f.write(f"{i}|{w.replace('|','\\p')}\n")
    def load(self, path):
        if not os.path.exists(path): return
        with open(path) as f:
            for line in f:
                line = line.rstrip("\n")
                if "|" in line:
                    i,w = line.split("|",1)
                    w = w.replace("\\p","|")
                    i = int(i)
                    self.w2i[w]=i; self.i2w[i]=w
                    if i >= self.next_id: self.next_id = i+1

###############################################################################
#  TRANSITION CORE MODULE  (PyTorch, 12-bit prob weights)
###############################################################################

class TransitionCore(nn.Module):
    """
    Learnable transition probability table.
    Stored as (state_embedding, next_state_logit) pairs.
    At inference: top-k next states → 12-bit log-scale prob export.
    """
    def __init__(self, vocab_size, d_model):
        super().__init__()
        self.vocab_size = vocab_size
        self.d = d_model
        # State embedding: vocab → d
        self.state_embed = nn.Embedding(vocab_size, d_model, padding_idx=0)
        # Transition projector: d → d (query for next-state scoring)
        self.W_trans = nn.Linear(d_model, d_model, bias=False)
        # Cached 12-bit probability tables for Lua export
        self._prob_cache = {}   # (from_id, to_id) → prob12

    def forward(self, state_ids: torch.Tensor) -> torch.Tensor:
        """
        state_ids: (B, T)
        Returns: (B, T, V) logits over next states
        """
        emb = self.state_embed(state_ids)      # (B,T,d)
        q   = self.W_trans(emb)                # (B,T,d)
        # Score against all state embeddings
        all_emb = self.state_embed.weight      # (V,d)
        logits  = torch.matmul(q, all_emb.T)  # (B,T,V)
        return logits

    def export_transitions(self, top_k=16):
        """
        Export top-k transitions per state in Lua-compatible format.
        Returns: list of (state_hash, [(target_hash, prob12, type),...])
        """
        self.eval()
        results = []
        with torch.no_grad():
            W = self.state_embed.weight    # (V,d)
            q = self.W_trans(W)            # (V,d)
            logits = torch.matmul(q, W.T) # (V,V)
            probs  = torch.softmax(logits, dim=-1)   # (V,V)
            top_probs, top_ids = probs.topk(top_k, dim=-1)   # (V,k)

        for sid in range(min(self.vocab_size, W.shape[0])):
            sh = fnv1a32(str(sid).encode())
            transitions = []
            for k in range(top_k):
                tid   = top_ids[sid][k].item()
                p     = top_probs[sid][k].item()
                p12   = prob_encode12(p)
                th    = fnv1a32(str(tid).encode())
                transitions.append((th & 0xFFFFFF, p12, 0))  # direct type=0
            results.append((sh, transitions))
        return results

###############################################################################
#  ENGRAM LAYER v2  (multi-branch, depthwise conv, TC-gated)
###############################################################################

class EngramV2(nn.Module):
    def __init__(self, d_model, max_ngram=3, bucket_size=300_000,
                 vocab_size=50_000, n_branches=4):
        super().__init__()
        self.d, self.max_ngram = d_model, max_ngram
        self.bucket_size, self.n_branches = bucket_size, n_branches

        # N-gram embedding tables (sparse)
        self.tables = nn.ModuleList([
            nn.Embedding(bucket_size, d_model, sparse=True, padding_idx=0)
            for _ in range(max_ngram)
        ])
        # Shared Value projection W_V (spec §2.4: shared across branches)
        self.W_V = nn.Linear(d_model, d_model, bias=False)
        # Branch-specific Key projections W_K^(m)
        self.W_K = nn.ModuleList([
            nn.ModuleList([nn.Linear(d_model, d_model, bias=False)
                           for _ in range(max_ngram)])
            for _ in range(n_branches)
        ])
        # Depthwise conv (spec §2.3 refinement, 3-tap)
        self.conv = nn.Conv1d(d_model, d_model, 3, padding=1, groups=d_model)

    @staticmethod
    def hash_ngram(token_ids: list, bucket_size: int) -> int:
        key = "_".join(map(str, token_ids))
        return (fnv1a32(key.encode()) % (bucket_size-1)) + 1

    def forward(self, token_ids: torch.Tensor,
                hidden: torch.Tensor) -> torch.Tensor:
        """
        token_ids: (B,T) long
        hidden:    (B,T,d)
        Returns:   (B,T,d)
        """
        B, T = token_ids.shape
        d    = self.d
        dev  = hidden.device
        h_norm = F.rms_norm(hidden, [d])   # (B,T,d)

        # Multi-branch fusion
        fused    = torch.zeros(B, T, d, device=dev)
        gate_sum = torch.zeros(B, T, 1, device=dev)

        ids_list = token_ids.cpu().tolist()

        for n in range(1, self.max_ngram + 1):
            # Build bucket indices
            buckets = torch.zeros(B, T, dtype=torch.long, device=dev)
            for b in range(B):
                for t in range(T):
                    start  = max(0, t - n + 1)
                    suffix = ids_list[b][start:t+1]
                    buckets[b,t] = self.hash_ngram(suffix, self.bucket_size)

            emb    = self.tables[n-1](buckets)             # (B,T,d)
            e_norm = F.rms_norm(emb, [d])

            # Aggregate gates across branches (spec §2.4 Eq.6)
            branch_gates = []
            for m in range(self.n_branches):
                k_proj = self.W_K[m][n-1](e_norm)         # (B,T,d)
                score  = (h_norm * F.rms_norm(k_proj,[d])).sum(-1,keepdim=True) \
                         / math.sqrt(d)
                branch_gates.append(torch.sigmoid(score))   # (B,T,1)
            gate = torch.stack(branch_gates, dim=0).mean(0) # (B,T,1)

            order_w = 1.0 + (n-1) * 0.3
            fused   += gate * order_w * emb
            gate_sum += gate * order_w

        fused = fused / (gate_sum + 1e-9)
        fused = self.W_V(fused)                            # (B,T,d)

        # Depthwise conv refinement
        fused = self.conv(fused.transpose(1,2)).transpose(1,2)  # (B,T,d)
        return fused

###############################################################################
#  SSM LAYER v2  (TC-conditioned Δ)
###############################################################################

class SSMLayerV2(nn.Module):
    def __init__(self, d_model, d_state=16):
        super().__init__()
        self.d, self.N = d_model, d_state
        self.in_proj   = nn.Linear(d_model, d_model*2, bias=False)
        self.out_proj  = nn.Linear(d_model, d_model,   bias=False)
        self.W_B       = nn.Linear(d_model, d_state,   bias=False)
        self.W_C       = nn.Linear(d_model, d_state,   bias=False)
        # W_dt conditioned by TC confidence (spec §3 TransitionEntry prob)
        self.W_dt      = nn.Linear(d_model + 1, d_model, bias=True)  # +1 for TC signal
        self.log_A     = nn.Parameter(torch.randn(d_state))
        self.W_eng     = nn.Linear(d_model, d_model, bias=False)
        self.norm1     = nn.RMSNorm(d_model)
        self.norm2     = nn.RMSNorm(d_model)

    def forward(self, x: torch.Tensor,
                engram_v: torch.Tensor = None,
                tc_confidence: torch.Tensor = None) -> torch.Tensor:
        """
        x:             (B,T,d)
        engram_v:      (B,T,d) or None
        tc_confidence: (B,T,1) scalar in [0,1] from TransitionCore
        """
        B,T,d = x.shape
        res = x
        x = self.norm1(x)
        xg = self.in_proj(x)
        x_ssm, z = xg.chunk(2, dim=-1)
        x_ssm = F.silu(x_ssm)
        z     = torch.sigmoid(z)

        B_t = F.normalize(self.W_B(x_ssm), dim=-1)
        C_t = F.normalize(self.W_C(x_ssm), dim=-1)

        # TC-conditioned timescale Δ (high TC confidence → shorter horizon)
        if tc_confidence is not None:
            dt_in = torch.cat([x_ssm, tc_confidence], dim=-1)  # (B,T,d+1)
        else:
            dt_in = torch.cat([x_ssm,
                torch.zeros(B,T,1,device=x.device,dtype=x.dtype)], dim=-1)
        dt    = F.softplus(self.W_dt(dt_in))                # (B,T,d)
        dt_s  = dt.mean(-1, keepdim=True)                   # (B,T,1)

        # Selective scan
        A     = -torch.exp(self.log_A)                       # (N,)
        Abar  = torch.exp(dt_s * A.unsqueeze(0).unsqueeze(0))  # (B,T,N)
        Bbar  = (Abar-1)/(A+1e-9) * B_t
        x_sc  = x_ssm.mean(-1, keepdim=True)

        h = torch.zeros(B, self.N, device=x.device, dtype=x.dtype)
        ys = []
        for t in range(T):
            h = Abar[:,t,:]*h + Bbar[:,t,:]*x_sc[:,t,:]
            y_t = (C_t[:,t,:]*h).sum(-1, keepdim=True)
            ys.append(y_t.unsqueeze(1))
        y_ssm = torch.cat(ys,dim=1).expand(B,T,d)

        y = y_ssm * z

        if engram_v is not None:
            e = self.W_eng(self.norm2(engram_v))
            g = torch.sigmoid(e.pow(2).mean(-1,keepdim=True))
            y = y + g * e

        return self.out_proj(y) + res

###############################################################################
#  MoE  (8 experts, top-2)
###############################################################################

class MoEV2(nn.Module):
    def __init__(self, d, n_exp=8, top_k=2):
        super().__init__()
        self.E,self.K = n_exp,top_k
        self.router   = nn.Linear(d,n_exp,bias=False)
        self.experts  = nn.ModuleList([
            nn.Sequential(nn.Linear(d,d*4,bias=False),nn.SiLU(),
                          nn.Linear(d*4,d,bias=False))
            for _ in range(n_exp)])
        self.norm = nn.RMSNorm(d)
    def forward(self,x):
        res=x; x=self.norm(x); B,T,d=x.shape
        logits  = self.router(x)
        w,idx   = logits.softmax(-1).topk(self.K,dim=-1)
        out     = torch.zeros_like(x)
        for k in range(self.K):
            ei = idx[...,k]; wk = w[...,k:k+1]
            for e in range(self.E):
                m = (ei==e)
                if m.any(): out[m] += wk[m]*self.experts[e](x[m])
        return out+res

###############################################################################
#  FULL MODEL v2
###############################################################################

class SSMChatModelV2(nn.Module):
    def __init__(self, vocab_size, d_model=128, n_layers=4,
                 d_state=32, max_ngram=3, bucket_size=300_000, n_branches=4):
        super().__init__()
        self.d = d_model
        self.embed     = nn.Embedding(vocab_size, d_model, padding_idx=0)
        self.tc        = TransitionCore(vocab_size, d_model)
        self.engram    = EngramV2(d_model, max_ngram, bucket_size,
                                  vocab_size, n_branches)
        self.layers    = nn.ModuleList([SSMLayerV2(d_model,d_state)
                                        for _ in range(n_layers)])
        self.moes      = nn.ModuleList([MoEV2(d_model)
                                        for _ in range(n_layers)])
        self.head      = nn.Linear(d_model, vocab_size, bias=False)
        self.norm_out  = nn.RMSNorm(d_model)
        self.head.weight = self.embed.weight  # weight tying

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        h   = self.embed(input_ids)                     # (B,T,d)
        eng = self.engram(input_ids, h)                 # (B,T,d)

        # TransitionCore confidence signal
        tc_logits  = self.tc(input_ids)                 # (B,T,V)
        tc_conf    = tc_logits.softmax(-1).max(-1, keepdim=True)[0]  # (B,T,1)

        for ssm, moe in zip(self.layers, self.moes):
            h = ssm(h, eng, tc_conf)
            h = moe(h)

        return self.head(self.norm_out(h))              # (B,T,V)

###############################################################################
#  MARKOV RL KNOWLEDGE INJECTOR v2
###############################################################################

class MarkovRLV2:
    def __init__(self, model, tok, device,
                 gamma=0.9, lr_q=0.05, epsilon=0.2, n_bins=64):
        self.model,self.tok,self.device = model,tok,device
        self.gamma,self.lr_q,self.epsilon,self.bins = gamma,lr_q,epsilon,n_bins
        self.Q      = defaultdict(lambda: defaultdict(float))
        self.cases  = []
        self.actions = {}   # id → (q,r)
        self.n_act  = 0

    def _state(self, text):
        ids,_ = self.tok.encode(text, max_len=32)
        if not ids: return 0
        t = torch.tensor([ids], dtype=torch.long, device=self.device)
        with torch.no_grad():
            logits = self.model(t)[0].mean(0)
            bits   = (logits[:self.bins] >= 0).long()
            s      = 0
            for b in bits.tolist(): s = s*2+b
        return s % self.bins

    def _reward(self, q, r):
        text = f"Human: {q}\nAssistant: {r}"
        ids,_ = self.tok.encode(text, max_len=64)
        if len(ids) < 2: return 0.0
        t   = torch.tensor([ids[:-1]], dtype=torch.long, device=self.device)
        tgt = torch.tensor([ids[1:]],  dtype=torch.long, device=self.device)
        with torch.no_grad():
            logits = self.model(t)
            loss   = F.cross_entropy(logits.view(-1,logits.size(-1)),
                                     tgt.view(-1), reduction="mean")
        return -loss.item()

    def inject(self, dataset, max_pairs=5000, n_ep=2):
        print(f"\n🧠 Markov RL v2  ({len(dataset)} samples, {n_ep} episodes)")
        self.model.eval()
        for i,row in enumerate(dataset):
            if i >= max_pairs: break
            text = row.get("text","")
            if "\nAssistant:" in text:
                q,r = text.split("\nAssistant:",1)
                q = q.replace("Human:","").strip(); r = r.strip()
            else:
                w = text.split(); m=len(w)//2
                q,r = " ".join(w[:m])," ".join(w[m:])
            if len(q)>5 and len(r)>5:
                self.actions[self.n_act]=(q,r); self.n_act+=1

        print(f"  Actions: {self.n_act}")
        best = {}

        for ep in range(n_ep):
            ep_r=0; pairs=list(self.actions.items()); random.shuffle(pairs)
            for aid,(q,r) in pairs:
                s  = self._state(q)
                a  = random.randint(0,self.n_act-1) \
                     if random.random()<self.epsilon \
                     else max(self.Q[s], key=self.Q[s].get, default=aid)
                rw = self._reward(q,r); ep_r+=rw
                s2 = self._state(r)
                nq = max(self.Q[s2].values(), default=0.0)
                self.Q[s][aid] += self.lr_q*(rw+self.gamma*nq-self.Q[s][aid])
                best[aid] = max(best.get(aid,-999), rw)
            print(f"  Ep {ep+1}/{n_ep}  avg_r={ep_r/max(1,self.n_act):.4f}")

        top = sorted(best.items(), key=lambda kv:kv[1], reverse=True)
        for aid,rw in top[:2000]:
            q,r = self.actions[aid]; self.cases.append({"q":q,"r":r,"reward":rw})
        print(f"  ✓ {len(self.cases)} cases retained")

    def export_cbr(self, path):
        with open(path,"w") as f:
            f.write(f"NCASES={len(self.cases)}\n")
            for i,c in enumerate(self.cases,1):
                q = c["q"].replace("\n","\\n").replace("|","\\p")
                r = c["r"].replace("\n","\\n").replace("|","\\p")
                f.write(f"CASE|{i}|{q}|{r}|{c['reward']:.4f}|0|\n")
        print(f"[RL] Exported {len(self.cases)} cases → {path}")

###############################################################################
#  EXPORT ENGRAM TO LUA FORMAT
###############################################################################

def export_engram_lua(model: SSMChatModelV2, path: str):
    d   = model.d
    ngm = model.engram.max_ngram
    bsz = model.engram.bucket_size
    nb  = model.engram.n_branches
    with open(path,"w") as f:
        f.write(f"DIM={d}\nMAX_NGRAM={ngm}\nBUCKETS={bsz}\nBRANCHES={nb}\n")
        for ni,table in enumerate(model.engram.tables):
            n = ni+1
            w = table.weight.detach().cpu()
            norms = w.norm(dim=1)
            active = (norms>0.01).nonzero(as_tuple=True)[0]
            for bkt in active.tolist():
                vec = w[bkt].tolist()
                vals = ",".join(f"{v:.6f}" for v in vec)
                f.write(f"E|{n}|{bkt}|{vals}\n")
        # W_V
        wv = model.engram.W_V.weight.detach().cpu()
        # Average diagonal as shared W_V vec (simplified for Lua scalar gate)
        wv_diag = [wv[i][i].item() if i<wv.shape[1] else 0.0 for i in range(d)]
        f.write("WV|" + ",".join(f"{v:.6f}" for v in wv_diag) + "\n")
    print(f"[Export] Engram v2 → {path}  ({len(active)} active buckets)")

def export_transition_core_lua(model: SSMChatModelV2, path: str, top_k=8):
    """Export TC transition probabilities in Lua CTC binary format (simplified)."""
    transitions = model.tc.export_transitions(top_k)
    with open(path,"w") as f:
        f.write(f"NSTATES={len(transitions)}\n")
        for sh, trans in transitions[:50000]:   # cap to top 50K states
            parts = [str(sh)]
            for target24, p12, ttype in trans:
                parts.append(f"{target24}:{p12}:{ttype}")
            f.write("|".join(parts) + "\n")
    print(f"[Export] TransitionCore → {path}  ({len(transitions)} states)")

###############################################################################
#  TRAINER
###############################################################################

class TrainerV2:
    def __init__(self, model, tok, device, cfg):
        self.model,self.tok,self.device,self.cfg = model,tok,device,cfg
        self.opt    = torch.optim.AdamW(model.parameters(),lr=cfg.lr,weight_decay=0.01)
        self.scaler = torch.cuda.amp.GradScaler(enabled=cfg.fp16 if hasattr(cfg,"fp16") else False)

    def collate(self, batch, max_len=256):
        rows=[]
        for row in batch:
            t=row.get("text",""); ids,_=self.tok.encode(t,max_len+1)
            if len(ids)>=2: rows.append(ids[:max_len+1])
        if not rows: return None,None
        ml=max(len(r) for r in rows)
        pad=[[*r]+[0]*(ml-len(r)) for r in rows]
        t=torch.tensor(pad,dtype=torch.long,device=self.device)
        return t[:,:-1],t[:,1:]

    def epoch(self, ds, ep):
        self.model.train()
        loader=torch.utils.data.DataLoader(ds,batch_size=self.cfg.batch_size,
                                           shuffle=True,collate_fn=lambda b:b)
        if TPU_AVAILABLE:
            dev=xm.xla_device()
            loader=pl.MpDeviceLoader(loader,dev)
        tot,steps=0.0,0
        for i,batch in enumerate(loader):
            inp,tgt=self.collate(batch)
            if inp is None: continue
            with torch.cuda.amp.autocast(enabled=False):
                logits=self.model(inp)
                loss=F.cross_entropy(logits.reshape(-1,logits.size(-1)),
                                     tgt.reshape(-1),ignore_index=0)
            self.opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(),1.0)
            self.opt.step()
            if TPU_AVAILABLE: xm.mark_step()
            tot+=loss.item(); steps+=1
            if i%max(1,len(loader)//8)==0:
                ppl=math.exp(min(tot/max(1,steps),20))
                print(f"  Ep{ep} step{i}  loss={tot/steps:.4f} ppl={ppl:.2f}")
        return tot/max(1,steps)

    def train(self, ds):
        print(f"\n🚀 Training epochs={self.cfg.epochs} bs={self.cfg.batch_size} lr={self.cfg.lr}")
        for ep in range(1,self.cfg.epochs+1):
            loss=self.epoch(ds,ep)
            print(f"✓ Ep{ep} avg_loss={loss:.4f} ppl={math.exp(min(loss,20)):.2f}\n")

###############################################################################
#  MAIN
###############################################################################

def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument("--dataset",    default="daily_dialog")
    p.add_argument("--split",      default="train")
    p.add_argument("--text_col",   default="text")
    p.add_argument("--input_col",  default="input")
    p.add_argument("--output_col", default="output")
    p.add_argument("--epochs",     type=int,   default=3)
    p.add_argument("--batch_size", type=int,   default=16)
    p.add_argument("--lr",         type=float, default=3e-4)
    p.add_argument("--d_model",    type=int,   default=128)
    p.add_argument("--n_layers",   type=int,   default=4)
    p.add_argument("--d_state",    type=int,   default=32)
    p.add_argument("--max_ngram",  type=int,   default=3)
    p.add_argument("--n_branches", type=int,   default=4)
    p.add_argument("--bucket_size",type=int,   default=300_000)
    p.add_argument("--vocab_size", type=int,   default=50_000)
    p.add_argument("--rl_pairs",   type=int,   default=3000)
    p.add_argument("--rl_episodes",type=int,   default=2)
    p.add_argument("--fp16",       action="store_true")
    p.add_argument("--output_dir", default="./out_v2")
    return p.parse_args()

def main():
    cfg=parse_args()
    os.makedirs(cfg.output_dir+"/checkpoints_v2",exist_ok=True)

    if TPU_AVAILABLE:
        device=xm.xla_device(); print(f"Device: TPU {device}")
    elif torch.cuda.is_available():
        device=torch.device("cuda"); print(f"Device: GPU {torch.cuda.get_device_name()}")
    else:
        device=torch.device("cpu"); print("Device: CPU")

    ds=load_data(cfg.dataset,cfg.split,cfg.text_col,cfg.input_col,cfg.output_col)
    print(f"Dataset: {len(ds)}")

    tok=SimpleTokenizer(cfg.vocab_size)
    tok.load(cfg.output_dir+"/vocab.dat")
    print("Building vocab…")
    for i,row in enumerate(ds):
        if i>=50000: break
        tok.encode(row.get("text",""),512)
    tok.save(cfg.output_dir+"/vocab.dat")
    print(f"Vocab: {len(tok)}")

    model=SSMChatModelV2(
        vocab_size=len(tok), d_model=cfg.d_model, n_layers=cfg.n_layers,
        d_state=cfg.d_state, max_ngram=cfg.max_ngram,
        bucket_size=cfg.bucket_size, n_branches=cfg.n_branches).to(device)
    print(f"Params: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

    # Markov RL injection (BEFORE training)
    rl=MarkovRLV2(model,tok,device,n_bins=64)
    rl.inject(ds,max_pairs=cfg.rl_pairs,n_ep=cfg.rl_episodes)
    rl.export_cbr(cfg.output_dir+"/checkpoints_v2/cbr_v2.dat")

    # Train
    trainer=TrainerV2(model,tok,device,cfg)
    trainer.train(ds)

    # Save
    torch.save({"model":model.state_dict(),"cfg":vars(cfg),"vocab":len(tok)},
               cfg.output_dir+"/model_v2.pt")
    print(f"✓ PyTorch checkpoint → {cfg.output_dir}/model_v2.pt")

    # Export Lua-compatible checkpoints
    ckdir=cfg.output_dir+"/checkpoints_v2"
    export_engram_lua(model, ckdir+"/engram_v2.dat")
    export_transition_core_lua(model, ckdir+"/store/transition_core.ctc")
    tok.save(ckdir+"/vocab.dat")

    print(f"\n✅ All done! Copy {ckdir}/ → Lua bot directory, then:")
    print("   luajit chatbot_v2.lua")

if __name__=="__main__":
    main()
