-- ================================================================
--  cbr_v2.lua  ─  Case-Based Reasoning v2
--
--  Integrates with USTCC StateStore:
--    • Case storage uses CaseLibrary (block-compressed, 100M cap)
--    • Pattern matching via PatternDictionary (65K patterns, slots)
--    • Markov Q-table states = TransitionCore state signatures
--    • Bloom filter guards CBR retrieval (fast-reject unknowns)
--    • RL reward propagates back into TransitionCore weights
--    • Cold Archive stores infrequent cases, promoted on reuse
--
--  CBR Cycle:  RETRIEVE  →  REUSE (ε-greedy Markov)
--              →  REVISE  →  RETAIN (CaseLibrary.add)
-- ================================================================

local SS = require("state_store")

local CBR = {}
CBR.__index = CBR

-- ────────────────────────────────────────────────────────────────
--  Math helpers
-- ────────────────────────────────────────────────────────────────

local function fnv1a(s) return SS.Enc.fnv1a32(s) end

local function dot(a, b)
    local s=0; for i=1,#a do s=s+(a[i] or 0)*(b[i] or 0) end; return s
end

local function norm2(v)
    local s=0; for i=1,#v do s=s+v[i]*v[i] end; return math.sqrt(s+1e-9)
end

local function cosine(a, b) return dot(a,b)/(norm2(a)*norm2(b)) end

-- Discretise hidden vector into Markov state bucket
-- Uses sign-bit projection (spec §7 adaptation)
local function state_of(hidden, n_buckets)
    n_buckets = n_buckets or 128
    if not hidden or #hidden == 0 then return 0 end
    local step = math.ceil(#hidden / 16)
    local sig  = 0
    for i=1,#hidden,step do
        sig = sig*2 + (hidden[i] >= 0 and 1 or 0)
    end
    return sig % n_buckets
end

-- Embed text to vector using FNV-based bag-of-words
local function embed_text(text, dim)
    dim = dim or 128
    local v = {}
    for i=1,dim do v[i]=0.0 end
    for word in text:lower():gmatch("%S+") do
        local h = fnv1a(word)
        local pos = (h % dim) + 1
        local mag = ((h >> 8) % 200) / 200.0 - 1.0
        v[pos] = v[pos] + mag
    end
    local n = norm2(v)
    for i=1,dim do v[i] = v[i]/n end
    return v
end

-- ────────────────────────────────────────────────────────────────
--  Constructor
-- ────────────────────────────────────────────────────────────────

---@param cfg table
--- cfg.dim              embedding dim             (128)
--- cfg.sim_thresh       min cosine for retrieval  (0.60)
--- cfg.epsilon          Markov ε-greedy           (0.15)
--- cfg.gamma            Markov discount           (0.90)
--- cfg.lr_q             Q-learning rate           (0.10)
--- cfg.n_state_buckets  Markov state bins         (128)
--- cfg.store            StateStore instance
function CBR.new(cfg)
    local self = setmetatable({}, CBR)
    cfg = cfg or {}
    self.dim          = cfg.dim        or 128
    self.sim_thresh   = cfg.sim_thresh or 0.60
    self.epsilon      = cfg.epsilon    or 0.15
    self.gamma        = cfg.gamma      or 0.90
    self.lr_q         = cfg.lr_q       or 0.10
    self.n_buckets    = cfg.n_state_buckets or 128
    self.store        = cfg.store              -- StateStore

    -- ── In-memory case index (mirrors CaseLibrary, subset)
    -- Stores { query_emb, response, case_id, reward_sum, uses } for fast retrieval
    -- Full case data lives in CaseLibrary on disk.
    self.index        = {}    -- list of case summary records
    self.n_cases      = 0
    self.max_hot_cases = cfg.max_cases or 5000

    -- ── Markov Q-table (spec §7 RL adaptation)
    -- Q[state_bucket][case_idx] = float
    self.Q = {}
    for i=0,self.n_buckets-1 do self.Q[i] = {} end

    -- ── Episode tracking for Bellman update
    self.last_state  = nil
    self.last_action = nil

    -- ── Stats
    self.stats = { retrieved=0, revised=0, retained=0, rl_updates=0,
                   pattern_hits=0, bloom_rejects=0 }

    return self
end

-- ────────────────────────────────────────────────────────────────
--  §RETRIEVE  — cosine search with bloom pre-filter
-- ────────────────────────────────────────────────────────────────

function CBR:retrieve(query_text, top_k)
    top_k = top_k or 5
    local q_emb = embed_text(query_text, self.dim)
    local q_hash = fnv1a(query_text:lower():sub(1,64))

    -- Bloom-filter guard: skip known unknowns
    if not self.store.bloom:check(q_hash) and self.n_cases > 100 then
        self.stats.bloom_rejects = self.stats.bloom_rejects + 1
        return {}, q_emb
    end

    -- Scan in-memory index
    local scored = {}
    for i=1, self.n_cases do
        local c = self.index[i]
        if c and c.query_emb then
            local sim = cosine(q_emb, c.query_emb)
            if sim >= self.sim_thresh then
                scored[#scored+1] = { idx=i, sim=sim, case=c }
            end
        end
    end

    table.sort(scored, function(a,b) return a.sim > b.sim end)
    local results = {}
    for i=1,math.min(top_k,#scored) do
        results[i] = scored[i]
    end

    self.stats.retrieved = self.stats.retrieved + 1
    return results, q_emb
end

-- ────────────────────────────────────────────────────────────────
--  §REUSE — ε-greedy Markov action selection
--  State = discretised SSM hidden; Action = case index
-- ────────────────────────────────────────────────────────────────

function CBR:select(candidates, hidden_vec)
    if #candidates == 0 then return nil end

    local s     = state_of(hidden_vec, self.n_buckets)
    local q_row = self.Q[s] or {}

    local chosen
    if math.random() < self.epsilon then
        -- Explore: random candidate
        chosen = candidates[math.random(#candidates)]
    else
        -- Exploit: best Q(s, a) among candidates
        local best_q = -math.huge
        for _, cand in ipairs(candidates) do
            local q = q_row[cand.idx] or cand.sim
            if q > best_q then best_q = q; chosen = cand end
        end
    end

    self.last_state  = s
    self.last_action = chosen and chosen.idx or nil

    if chosen and chosen.case then
        chosen.case.uses = (chosen.case.uses or 0) + 1
    end

    return chosen
end

-- ────────────────────────────────────────────────────────────────
--  §REVISE — adapt retrieved response to current query
-- ────────────────────────────────────────────────────────────────

function CBR:revise(retrieved_response, current_query, sim_score)
    if not retrieved_response then return nil end
    self.stats.revised = self.stats.revised + 1

    -- Very high sim → reuse verbatim
    if sim_score and sim_score > 0.92 then
        return retrieved_response
    end

    -- Mid sim: minimal adaptation flag
    local adapted = retrieved_response
    if sim_score and sim_score < 0.75 then
        -- Hook for future NLG slot-filling
        adapted = adapted:gsub("%.$", "") .. "."  -- normalise punctuation
    end
    return adapted
end

-- ────────────────────────────────────────────────────────────────
--  §RETAIN — store new case in index + CaseLibrary
-- ────────────────────────────────────────────────────────────────

function CBR:retain(query, response, query_emb, state_chain, success_rate)
    query_emb = query_emb or embed_text(query, self.dim)

    -- Deduplication: skip if very similar already exists
    if self.n_cases > 0 then
        local results = self:retrieve(query, 1)
        if results[1] and results[1].sim > 0.95 then
            -- Update reward of existing case
            local c = self.index[results[1].idx]
            if c then c.reward_sum = (c.reward_sum or 0) + 0.1 end
            return false
        end
    end

    -- Evict if at capacity
    if self.n_cases >= self.max_hot_cases then
        self:_evict_one()
    end

    -- Add to in-memory index
    self.n_cases = self.n_cases + 1
    local case_summary = {
        query     = query,
        response  = response,
        query_emb = query_emb,
        reward_sum = 0.0,
        uses       = 0,
        timestamp  = os.time(),
    }
    self.index[self.n_cases] = case_summary

    -- Record in CaseLibrary (persistent, block-compressed)
    local chain = state_chain or {}
    if #chain == 0 then
        -- Build a minimal chain from text hashes
        for word in query:lower():gmatch("%S+") do
            chain[#chain+1] = fnv1a(word)
        end
    end

    local case_id = self.store.cases:add({
        entry_state  = chain[1] or 0,
        chain_length = #chain,
        custom_chain = chain,
        pattern_id   = 0,
        success_rate = success_rate or 0.5,
        usage_count  = 0,
        query        = query,
        response     = response,
    })

    -- Add query hash to bloom filter so future retrieves can fast-path
    self.store.bloom:add(fnv1a(query:lower():sub(1,64)))

    self.stats.retained = self.stats.retained + 1
    return true
end

-- Evict the case with lowest utility = reward/uses, oldest timestamp
function CBR:_evict_one()
    local worst_idx, worst_score = 1, math.huge
    for i=1,self.n_cases do
        local c = self.index[i]
        if c then
            local u = (c.reward_sum+0.01) / (c.uses+1)
            local a = os.time() - (c.timestamp or 0)
            local s = u / (1 + a*0.0001)
            if s < worst_score then worst_score=s; worst_idx=i end
        end
    end
    -- Compact: replace with last
    self.index[worst_idx] = self.index[self.n_cases]
    self.index[self.n_cases] = nil
    self.n_cases = self.n_cases - 1
end

-- ────────────────────────────────────────────────────────────────
--  Main CBR query interface (full cycle)
-- ────────────────────────────────────────────────────────────────

function CBR:query(query_text, hidden_vec)
    -- 1. RETRIEVE
    local candidates, q_emb = self:retrieve(query_text, 5)

    -- 2. REUSE (Markov ε-greedy)
    local selected = self:select(candidates, hidden_vec)

    if not selected then return nil, q_emb, 0.0 end

    -- 3. REVISE
    local response = self:revise(
        selected.case.response, query_text, selected.sim)

    return response, q_emb, selected.sim
end

-- ────────────────────────────────────────────────────────────────
--  Markov Q-Learning Update (Bellman equation)
--  reward: float [-1, +1]
--  next_hidden: SSM hidden after response generation
-- ────────────────────────────────────────────────────────────────

function CBR:rl_update(reward, next_hidden_vec)
    if not self.last_state or not self.last_action then return end

    local s  = self.last_state
    local a  = self.last_action
    local ns = state_of(next_hidden_vec or {}, self.n_buckets)

    local q_sa   = (self.Q[s] or {})[a] or 0.0
    local max_ns = -math.huge
    for _, qv in pairs(self.Q[ns] or {}) do
        if qv > max_ns then max_ns = qv end
    end
    if max_ns == -math.huge then max_ns = 0 end

    -- Bellman: Q(s,a) ← Q(s,a) + α[r + γ·maxQ(s') - Q(s,a)]
    if not self.Q[s] then self.Q[s] = {} end
    self.Q[s][a] = q_sa + self.lr_q * (reward + self.gamma * max_ns - q_sa)

    -- Propagate reward to TransitionCore (strengthen/weaken transitions)
    if self.index[a] and reward ~= 0 then
        local c = self.index[a]
        c.reward_sum = (c.reward_sum or 0) + reward
        -- Update success_rate estimate
        c.success_rate = math.max(0, math.min(1,
            (c.success_rate or 0.5) * 0.9 + (reward > 0 and 0.1 or 0)))

        -- Nudge TransitionCore transition probabilities
        if c.query_emb then
            local qhash = fnv1a(c.query:lower():sub(1,64))
            local se = self.store.hot:get(qhash)
            if se and se.transitions and reward > 0 then
                for _, t in ipairs(se.transitions) do
                    local p = SS.Enc.prob_decode12(t.prob12)
                    t.prob12 = SS.Enc.prob_encode12(
                        math.min(1, p + reward * 0.02))
                end
            end
        end
    end

    self.stats.rl_updates = self.stats.rl_updates + 1
end

-- ────────────────────────────────────────────────────────────────
--  Pattern Discovery (background mining)
--  Scans recent custom-chain cases for frequent sequences.
--  If frequency > threshold → register new PatternEntry.
-- ────────────────────────────────────────────────────────────────

function CBR:mine_patterns(min_freq)
    min_freq = min_freq or 5
    -- Count subsequences across recent cases
    local seq_count = {}

    for i=1,self.n_cases do
        local c = self.index[i]
        if c and c.query then
            local words = {}
            for w in c.query:lower():gmatch("%S+") do words[#words+1]=w end
            -- Bigrams and trigrams
            for n=2,3 do
                for j=1,#words-n+1 do
                    local parts = {}
                    for k=j,j+n-1 do parts[#parts+1]=words[k] end
                    local seq_key = table.concat(parts, " ")
                    seq_count[seq_key] = (seq_count[seq_key] or 0) + 1
                end
            end
        end
    end

    -- Register frequent sequences as patterns
    local new_patterns = 0
    for seq, freq in pairs(seq_count) do
        if freq >= min_freq then
            local words = {}
            for w in seq:gmatch("%S+") do words[#words+1]=w end
            local state_seq = {}
            for _, w in ipairs(words) do
                state_seq[#state_seq+1] = fnv1a(w)
            end
            -- Add with one slot placeholder at end (variable completion)
            state_seq[#state_seq+1] = SS.SLOT_SENTINEL | 0
            local slot_defs = {{ type=SS.SLOT_TYPE.STRING, max_length=255 }}

            local pid = self.store.pdict:add_pattern(
                state_seq, slot_defs, "mined_" .. seq:gsub(" ","_"):sub(1,32))
            if pid then new_patterns = new_patterns + 1 end
        end
    end

    if new_patterns > 0 then
        print(("[CBR] Mined %d new patterns (%.1f%% of index)"):format(
            new_patterns, new_patterns/math.max(1,self.n_cases)*100))
    end
    return new_patterns
end

-- ────────────────────────────────────────────────────────────────
--  Bulk Knowledge Loading (from JSONL or pre-built CBR file)
-- ────────────────────────────────────────────────────────────────

function CBR:load_knowledge(path)
    local f = io.open(path, "r")
    if not f then print("[CBR v2] File not found: "..path); return 0 end
    local count = 0
    for line in f:lines() do
        -- Try JSON-like {"input":"...","output":"..."} patterns
        local q = line:match('"input"%s*:%s*"(.-)"')
            or line:match('"question"%s*:%s*"(.-)"')
            or line:match('"prompt"%s*:%s*"(.-)"')
            or line:match('"instruction"%s*:%s*"(.-)"')
        local r = line:match('"output"%s*:%s*"(.-)"')
            or line:match('"response"%s*:%s*"(.-)"')
            or line:match('"answer"%s*:%s*"(.-)"')
            or line:match('"completion"%s*:%s*"(.-)"')
            or line:match('"text"%s*:%s*"(.-)"')
        if q and r and #q > 3 and #r > 3 then
            -- Sanitise escapes
            q = q:gsub('\\"','"'):gsub("\\n","\n"):gsub("\\t","\t")
            r = r:gsub('\\"','"'):gsub("\\n","\n"):gsub("\\t","\t")
            local q_emb = embed_text(q, self.dim)
            self:retain(q, r, q_emb, nil, 0.7)
            count = count + 1
            if count % 1000 == 0 then
                io.write(("\r[CBR] Loaded %d pairs…"):format(count))
                io.flush()
            end
        end
    end
    f:close()
    print(("\n[CBR v2] Loaded %d QA pairs from %s"):format(count, path))

    -- Mine patterns after bulk load
    if count > 100 then self:mine_patterns(3) end

    return count
end

-- ────────────────────────────────────────────────────────────────
--  Persistence
-- ────────────────────────────────────────────────────────────────

function CBR:save(path)
    local f = assert(io.open(path, "w"))
    f:write("NCASES=" .. self.n_cases .. "\n")
    for i=1,self.n_cases do
        local c = self.index[i]
        if c then
            local q = (c.query    or ""):gsub("\n","\\n"):gsub("|","\\p")
            local r = (c.response or ""):gsub("\n","\\n"):gsub("|","\\p")
            local emb = c.query_emb and table.concat(c.query_emb,",") or ""
            f:write(("CASE|%d|%s|%s|%.4f|%d|%s\n"):format(
                i, q, r, c.reward_sum or 0, c.uses or 0, emb))
        end
    end
    -- Q-table
    for s, actions in pairs(self.Q) do
        for a, q in pairs(actions) do
            if q ~= 0 then
                f:write(("Q|%d|%d|%.6f\n"):format(s, a, q))
            end
        end
    end
    f:close()
    print(("[CBR v2] Saved %d cases → %s"):format(self.n_cases, path))
end

function CBR:load(path)
    local f = io.open(path, "r")
    if not f then print("[CBR v2] No checkpoint: "..path); return false end
    self.index   = {}
    self.n_cases = 0
    for line in f:lines() do
        if line:sub(1,4)=="CASE" then
            local parts={}
            for p in line:gmatch("[^|]+") do parts[#parts+1]=p end
            if #parts >= 5 then
                local q  = (parts[3] or ""):gsub("\\n","\n"):gsub("\\p","|")
                local r  = (parts[4] or ""):gsub("\\n","\n"):gsub("\\p","|")
                local emb=nil
                if parts[7] and #parts[7]>1 then
                    emb={}
                    for sv in parts[7]:gmatch("[^,]+") do emb[#emb+1]=tonumber(sv) end
                end
                self.n_cases=self.n_cases+1
                self.index[self.n_cases]={
                    query=q, response=r,
                    query_emb = emb or embed_text(q, self.dim),
                    reward_sum=tonumber(parts[5]) or 0,
                    uses=tonumber(parts[6]) or 0,
                    timestamp=os.time(),
                }
            end
        elseif line:sub(1,1)=="Q" then
            local s,a,qv=line:match("Q|(%d+)|(%d+)|([%-%d%.eE]+)")
            if s then
                s=tonumber(s); a=tonumber(a)
                if not self.Q[s] then self.Q[s]={} end
                self.Q[s][a]=tonumber(qv)
            end
        end
    end
    f:close()
    print(("[CBR v2] Loaded %d cases from %s"):format(self.n_cases, path))
    return true
end

return CBR
