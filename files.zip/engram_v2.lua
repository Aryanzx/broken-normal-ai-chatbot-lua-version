-- ================================================================
--  engram_v2.lua  ─  Conditional N-gram Memory (Engram) v2
--
--  Integrates with StateStore (USTCC architecture) for:
--    • Sparse retrieval via hashed N-grams (bloom-filtered)
--    • Transition probability lookup from TransitionCore
--    • Cold archive fallback for rare N-gram patterns
--    • Pattern dictionary compression of frequent sequences
--    • Hebbian + RL online update propagated to hot table
--    • Context-aware gating (RMSNorm dot-product, paper Eq.6)
-- ================================================================

local SS = require("state_store")

local Engram = {}
Engram.__index = Engram

-- ────────────────────────────────────────────────────────────────
--  Math helpers
-- ────────────────────────────────────────────────────────────────

local function sigmoid(x)  return 1/(1+math.exp(-x)) end

local function rms_norm(v)
    local ss = 0
    for i=1,#v do ss = ss + v[i]*v[i] end
    local rms = math.sqrt(ss/#v + 1e-9)
    local out = {}
    for i=1,#v do out[i] = v[i]/rms end
    return out
end

local function dot(a, b)
    local s=0; for i=1,#a do s = s + a[i]*(b[i] or 0) end; return s
end

local function vec_add_ip(a, b, alpha)
    for i=1,#a do a[i] = a[i] + alpha*(b[i] or 0) end
end

local function vec_clone(v)
    local c={}; for i=1,#v do c[i]=v[i] end; return c
end

local function rand_vec(dim, seed)
    local scale = math.sqrt(2/dim)
    local st = seed or 42
    local v = {}
    for i=1,dim do
        st = (st*1664525+1013904223) & 0xFFFFFFFF
        v[i] = ((st/0x80000000)-1)*scale
    end
    return v
end

-- ────────────────────────────────────────────────────────────────
--  Constructor
-- ────────────────────────────────────────────────────────────────

---@param cfg table
--- cfg.dim           embedding dimension      (default 128)
--- cfg.max_ngram     max N-gram order          (default 3)
--- cfg.vocab_size    canonical vocab size      (default 50000)
--- cfg.lr            Hebbian learning rate     (default 0.005)
--- cfg.store         StateStore instance       (required)
function Engram.new(cfg)
    local self       = setmetatable({}, Engram)
    self.dim         = cfg.dim       or 128
    self.max_ngram   = cfg.max_ngram or 3
    self.vocab_size  = cfg.vocab_size or 50000
    self.lr          = cfg.lr        or 0.005
    self.store       = cfg.store     -- StateStore instance

    -- Local embedding tables (lightweight, keyed by ngram hash)
    -- These are the "value" vectors (W_V in paper)
    -- The StateStore holds transition structure; embeddings are local.
    self.embed_tables = {}    -- n → { bucket → vec }
    for n = 1, self.max_ngram do
        self.embed_tables[n] = {}
    end

    -- Branch-specific Key projection matrices W_K^(m) (4 branches, §2.4)
    self.n_branches  = cfg.n_branches or 4
    self.W_K         = {}    -- branch → { n → weight_vec (dim) }
    local seed = 0
    for m = 1, self.n_branches do
        self.W_K[m] = {}
        for n = 1, self.max_ngram do
            seed = seed + 137
            self.W_K[m][n] = rand_vec(self.dim, seed)
        end
    end

    -- Shared Value projection W_V (dim × dim, simplified as vec scale)
    self.W_V  = rand_vec(self.dim, 9999)

    -- Depthwise conv kernel (3 taps, spec §2.3 refinement)
    self.conv_k = { 0.25, 0.5, 0.25 }

    -- Vocab projection cache (raw token → canonical id)
    self.vocab_proj  = {}

    -- State chain for current context (N-gram context tracking)
    self.state_chain = {}   -- list of { key, hash32 }

    -- Engram access stats
    self.stats = { retrievals=0, store_hits=0, cold_hits=0, updates=0 }

    return self
end

-- ────────────────────────────────────────────────────────────────
--  Tokenizer Compression
-- ────────────────────────────────────────────────────────────────

function Engram:canonicalize(token)
    local t = tostring(token):lower()
    t = t:gsub("^[Ġ▁ ]", ""):gsub("%s+", " "):gsub("^%s+", ""):gsub("%s+$", "")
    return t
end

function Engram:token_id(token)
    local c = self:canonicalize(token)
    if not self.vocab_proj[c] then
        self.vocab_proj[c] = (SS.Enc.fnv1a32(c) % self.vocab_size) + 1
    end
    return self.vocab_proj[c]
end

-- ────────────────────────────────────────────────────────────────
--  Embedding table access (lazy init, StateStore-aware)
-- ────────────────────────────────────────────────────────────────

function Engram:_ngram_key(token_ids, order)
    -- Build suffix n-gram string key
    local start = math.max(1, #token_ids - order + 1)
    local parts = {}
    for i = start, #token_ids do
        parts[#parts+1] = tostring(token_ids[i])
    end
    return "ng:" .. table.concat(parts, "_"), SS.Enc.fnv1a32(table.concat(parts,"_"))
end

function Engram:get_embed(n, ngram_key, ngram_hash)
    -- 1. Check local table
    if self.embed_tables[n][ngram_hash] then
        return self.embed_tables[n][ngram_hash]
    end

    -- 2. Check StateStore hot/cold for transition data
    --    → use transition probabilities as embedding weight signal
    local state_entry = self.store:lookup(ngram_key)
    if state_entry then
        -- Reconstruct embedding from transition probability mass
        local vec = rand_vec(self.dim, ngram_hash)
        -- Modulate by transition count (frequency → magnitude)
        local scale = math.log(1 + (state_entry.count or 1)) / 10.0
        for i = 1, self.dim do vec[i] = vec[i] * scale end
        self.embed_tables[n][ngram_hash] = vec
        self.stats.store_hits = self.stats.store_hits + 1
        return vec
    end

    -- 3. Initialise fresh (lazy Xavier)
    local vec = rand_vec(self.dim, ngram_hash * 31 + n * 7)
    self.embed_tables[n][ngram_hash] = vec
    return vec
end

-- ────────────────────────────────────────────────────────────────
--  §2.2  Sparse Retrieval via Hashed N-grams
-- ────────────────────────────────────────────────────────────────

--- Retrieve fused embedding for a token context.
--- tokens:   list of token strings (most-recent at end)
--- hidden:   optional SSM hidden state (dim) for gating (paper Eq.6)
--- branch:   which branch index m (1-based) for W_K^(m) selection
--- Returns:  fused embedding (dim)
function Engram:retrieve(tokens, hidden, branch)
    branch = branch or 1
    self.stats.retrievals = self.stats.retrievals + 1

    -- Encode tokens
    local ids = {}
    for _, t in ipairs(tokens) do
        ids[#ids+1] = self:token_id(t)
    end

    -- Build & record state chain (for StateStore transition tracking)
    for i = 2, #ids do
        local from_key = "ng1_" .. ids[i-1]
        local to_key   = "ng1_" .. ids[i]
        self.store:record_transition(from_key, to_key, SS.TRANS_TYPE.DIRECT)
    end

    -- RMSNorm of hidden state (for gating)
    local h_norm = hidden and rms_norm(hidden) or nil

    -- Fuse across N-gram orders
    local fused = {}
    for i = 1, self.dim do fused[i] = 0.0 end
    local gate_sum = 0.0
    local prev_emb = nil   -- for depthwise conv across orders

    for n = 1, math.min(self.max_ngram, #ids) do
        local ngkey, nghash = self:_ngram_key(ids, n)

        -- Bloom-filter guard (fast-reject unknown N-grams)
        if self.store.bloom:check(nghash) or n == 1 then
            local emb    = self:get_embed(n, ngkey, nghash)
            local e_norm = rms_norm(emb)

            -- Context-aware gate  (paper Eq.6)
            --   α^(m) = σ( RMSNorm(h)ᵀ · RMSNorm(W_K^(m) · e) / √d )
            local gate
            if h_norm then
                local wk     = self.W_K[branch][n]   -- (dim,)
                -- Approximate W_K · e as element-wise scale (efficient for CPU)
                local ke = {}
                for i = 1, self.dim do
                    ke[i] = wk[i] * e_norm[i]
                end
                local ke_norm = rms_norm(ke)
                local score   = dot(h_norm, ke_norm) / math.sqrt(self.dim)
                gate = sigmoid(score)
            else
                -- No hidden state: use lookup frequency as gate
                local se = self.store:lookup(ngkey)
                local freq = se and math.log(1 + se.count) / 20 or 0.3
                gate = sigmoid(freq - 0.5)
            end

            -- Order bonus (higher-order N-grams carry more specificity)
            local order_w = 1.0 + (n-1) * 0.3
            local w       = gate * order_w

            -- Depthwise conv across orders (3-tap, spec §2.3)
            local k0 = self.conv_k[1]
            local k1 = self.conv_k[2]
            local k2 = self.conv_k[3]
            for i = 1, self.dim do
                local prev  = prev_emb and prev_emb[i] or 0
                local curr  = emb[i]
                -- Causal conv: mix previous and current N-gram emb
                local convd = k0 * prev + k1 * curr +
                              k2 * (fused[i] / math.max(1, gate_sum))
                fused[i]   = fused[i] + w * convd
            end
            gate_sum = gate_sum + w
            prev_emb = emb
        end
    end

    -- Normalize
    if gate_sum > 1e-9 then
        for i = 1, self.dim do fused[i] = fused[i] / gate_sum end
    end

    -- Value projection: u = α · W_V · e  (shared W_V, per §2.4)
    for i = 1, self.dim do
        fused[i] = fused[i] * self.W_V[i]
    end

    return fused
end

-- ────────────────────────────────────────────────────────────────
--  §2.4  Multi-Branch Fusion
--  Retrieves across M=4 branches and sums gated outputs.
--  u = Σ_m  α^(m) · W_V · e
-- ────────────────────────────────────────────────────────────────

function Engram:retrieve_multibranch(tokens, hidden)
    local combined = {}
    for i = 1, self.dim do combined[i] = 0.0 end

    for m = 1, self.n_branches do
        local branch_out = self:retrieve(tokens, hidden, m)
        for i = 1, self.dim do
            combined[i] = combined[i] + branch_out[i]
        end
    end
    -- Average over branches
    for i = 1, self.dim do combined[i] = combined[i] / self.n_branches end
    return combined
end

-- ────────────────────────────────────────────────────────────────
--  Online Hebbian Update (RL-reward scaled)
--  target_emb: desired direction (e.g. next-token embedding)
--  reward:     scalar in [-1, +1]  from Markov Q-learning
-- ────────────────────────────────────────────────────────────────

function Engram:update(tokens, target_emb, reward)
    reward = reward or 1.0
    self.stats.updates = self.stats.updates + 1

    local ids = {}
    for _, t in ipairs(tokens) do ids[#ids+1] = self:token_id(t) end

    local target_norm = rms_norm(target_emb)

    for n = 1, math.min(self.max_ngram, #ids) do
        local ngkey, nghash = self:_ngram_key(ids, n)
        local emb = self.embed_tables[n][nghash]
        if not emb then
            emb = rand_vec(self.dim, nghash * 31 + n * 7)
            self.embed_tables[n][nghash] = emb
        end

        -- Cosine similarity between current emb and target
        local sim = 0
        local na, nb = 0, 0
        for i = 1, self.dim do
            sim = sim + emb[i]*target_norm[i]
            na  = na  + emb[i]*emb[i]
        end
        na = math.sqrt(na + 1e-9)
        sim = sim / na

        -- Hebbian: push emb toward target, weighted by reward
        local delta = reward * (1.0 - sim)
        vec_add_ip(emb, target_norm, self.lr * delta)

        -- Propagate reward signal to StateStore transition weights
        -- (update transition probability in hot table)
        local state_entry = self.store.hot:get(nghash)
        if state_entry then
            -- Boost frequency count proportionally to positive reward
            if reward > 0 then
                state_entry.count = state_entry.count + math.floor(reward * 5)
            end
        end

        -- Record N-gram access in StateStore bloom (keeps bloom fresh)
        self.store.bloom:add(nghash)
    end
end

-- ────────────────────────────────────────────────────────────────
--  Pattern-Aware Sequence Recording
--  Attempts to match the current token window to a known pattern.
--  If matched: stores pattern_id + slots (compressed).
--  If unmatched: stores as custom chain.
-- ────────────────────────────────────────────────────────────────

function Engram:record_sequence(tokens, response, success_rate)
    -- Build state chain (list of hash32 for each token)
    local chain = {}
    for _, t in ipairs(tokens) do
        chain[#chain+1] = SS.Enc.fnv1a32(self:canonicalize(t))
    end

    local query = table.concat(tokens, " ")
    self.store:record_case(query, response, chain, success_rate)
end

-- ────────────────────────────────────────────────────────────────
--  Statistics & Debug
-- ────────────────────────────────────────────────────────────────

function Engram:print_stats()
    local s = self.stats
    local n_buckets = 0
    for n = 1, self.max_ngram do
        for _ in pairs(self.embed_tables[n]) do n_buckets = n_buckets + 1 end
    end
    print("┌─── Engram v2 Stats ──────────────────────────────┐")
    print(("│  Retrievals:      %10d"):format(s.retrievals))
    print(("│  Store hits:      %10d"):format(s.store_hits))
    print(("│  Updates:         %10d"):format(s.updates))
    print(("│  Active buckets:  %10d"):format(n_buckets))
    print(("│  Vocab size:      %10d"):format(self.vocab_size))
    print("└──────────────────────────────────────────────────┘")
end

-- ────────────────────────────────────────────────────────────────
--  Persistence
-- ────────────────────────────────────────────────────────────────

function Engram:save(path)
    local f = assert(io.open(path, "w"))
    f:write("DIM=" .. self.dim .. "\n")
    f:write("MAX_NGRAM=" .. self.max_ngram .. "\n")
    f:write("BRANCHES=" .. self.n_branches .. "\n")

    -- Embedding tables
    for n = 1, self.max_ngram do
        for bucket, vec in pairs(self.embed_tables[n]) do
            f:write(("E|%d|%d|"):format(n, bucket) .. table.concat(vec,",") .. "\n")
        end
    end

    -- W_V
    f:write("WV|" .. table.concat(self.W_V, ",") .. "\n")

    -- W_K (branch × order)
    for m = 1, self.n_branches do
        for n = 1, self.max_ngram do
            f:write(("WK|%d|%d|"):format(m,n) .. table.concat(self.W_K[m][n],",") .. "\n")
        end
    end

    -- Vocab proj
    for tok, id in pairs(self.vocab_proj) do
        local safe = tok:gsub("|","\\p")
        f:write(("V|%s|%d\n"):format(safe, id))
    end

    f:close()
    print(("[Engram v2] Saved → " .. path))
end

function Engram:load(path)
    local f = io.open(path, "r")
    if not f then print("[Engram v2] No checkpoint: "..path); return false end
    for line in f:lines() do
        local tag = line:sub(1,2)
        if tag == "E|" or line:sub(1,1) == "E" then
            local n, bkt, vals = line:match("E|(%d+)|(%d+)|(.+)")
            n = tonumber(n); bkt = tonumber(bkt)
            if n and bkt then
                local v = {}
                for sv in vals:gmatch("[^,]+") do v[#v+1] = tonumber(sv) end
                self.embed_tables[n][bkt] = v
            end
        elseif line:sub(1,2) == "WV" then
            local vals = line:match("WV|(.+)")
            if vals then
                self.W_V = {}
                for sv in vals:gmatch("[^,]+") do self.W_V[#self.W_V+1]=tonumber(sv) end
            end
        elseif line:sub(1,2) == "WK" then
            local m, n, vals = line:match("WK|(%d+)|(%d+)|(.+)")
            m = tonumber(m); n = tonumber(n)
            if m and n then
                local v = {}
                for sv in vals:gmatch("[^,]+") do v[#v+1]=tonumber(sv) end
                if not self.W_K[m] then self.W_K[m]={} end
                self.W_K[m][n] = v
            end
        elseif line:sub(1,1) == "V" then
            local tok, id = line:match("V|(.+)|(%d+)$")
            if tok then
                tok = tok:gsub("\\p","|")
                self.vocab_proj[tok] = tonumber(id)
            end
        end
    end
    f:close()
    print("[Engram v2] Loaded from " .. path)
    return true
end

return Engram
