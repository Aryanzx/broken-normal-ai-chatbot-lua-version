-- ================================================================
--  ssm_v2.lua  ─  Advanced Selective State Space Model v2
--
--  Integrates StateStore for:
--    • Transition-guided beam search (use real probabilities from TC)
--    • Pattern Dictionary prefix matching → instant response lookup
--    • Cold Archive state recall for rare sequence completion
--    • Log-scale 12-bit probability for ultra-precise scoring
--    • Multi-branch Engram injection per SSM block
--    • MoE FFN with 8 experts (sparse, CPU-light)
--
--  Smart Loop = SSM recurrent scan + TC-guided scoring +
--               pattern early-exit + RL-weighted beam ranking
-- ================================================================

local SS = require("state_store")

local SSM = {}
SSM.__index = SSM

-- ────────────────────────────────────────────────────────────────
--  Math helpers
-- ────────────────────────────────────────────────────────────────

local function sigmoid(x)   return 1/(1+math.exp(-x)) end
local function silu(x)      return x*sigmoid(x) end
local function softplus(x)  return math.log(1+math.exp(x)) end

local function rms_norm(v, dim)
    local ss=0
    for i=1,#v do ss=ss+v[i]*v[i] end
    local rms=math.sqrt(ss/(dim or #v)+1e-9)
    local o={}; for i=1,#v do o[i]=v[i]/rms end; return o
end

local function dot(a,b)
    local s=0; for i=1,#a do s=s+(a[i] or 0)*(b[i] or 0) end; return s
end

local function matvec(W,x)
    local y={}
    for i=1,#W do
        local s=0
        for j=1,#W[i] do s=s+W[i][j]*(x[j] or 0) end
        y[i]=s
    end
    return y
end

local function vec_add(a,b)
    local c={}; for i=1,#a do c[i]=a[i]+(b[i] or 0) end; return c
end

local function vec_mul(a,b)
    local c={}; for i=1,#a do c[i]=a[i]*(b[i] or 0) end; return c
end

local function zeros(n)
    local v={}; for i=1,n do v[i]=0.0 end; return v
end

local function rand_mat(rows,cols,seed)
    seed=seed or 1
    local scale=math.sqrt(2/(rows+cols))
    local W,st={},seed
    for i=1,rows do
        W[i]={}
        for j=1,cols do
            st=(st*1664525+1013904223)&0xFFFFFFFF
            W[i][j]=((st/0x80000000)-1)*scale
        end
    end
    return W
end

local function rand_vec(n,seed)
    seed=seed or 1
    local scale=math.sqrt(2/n)
    local v,st={},seed
    for i=1,n do
        st=(st*1664525+1013904223)&0xFFFFFFFF
        v[i]=((st/0x80000000)-1)*scale
    end
    return v
end

-- Softmax with temperature
local function softmax_temp(v, temp)
    local mx=-math.huge
    for _,x in ipairs(v) do if x>mx then mx=x end end
    local s,out=0,{}
    for i,x in ipairs(v) do
        local e=math.exp((x-mx)/(temp+1e-9))
        out[i]=e; s=s+e
    end
    for i=1,#out do out[i]=out[i]/s end
    return out
end

-- ────────────────────────────────────────────────────────────────
--  SSM Block  (Mamba-style selective scan)
--  + Multi-branch Engram injection
--  + TransitionCore probability conditioning
-- ────────────────────────────────────────────────────────────────

local Block = {}
Block.__index = Block

function Block.new(d, N, engram, store, seed)
    local self = setmetatable({}, Block)
    self.d       = d
    self.N       = N
    self.engram  = engram
    self.store   = store

    -- Selective SSM parameters
    self.W_in    = rand_mat(d*2, d,  seed)
    self.W_out   = rand_mat(d,   d,  seed+1)
    self.W_B     = rand_mat(N,   d,  seed+2)
    self.W_C     = rand_mat(N,   d,  seed+3)
    self.W_dt    = rand_mat(d,   d,  seed+4)
    self.log_A   = rand_vec(N,   seed+5)   -- diag of log(-A), negative definite

    -- Engram fusion projection (shared W_V handled in Engram; here W_proj)
    self.W_engram = rand_mat(d, d, seed+6)

    -- TransitionCore conditioning: project state features to TC query
    self.W_tc_q   = rand_mat(d, d, seed+7)

    -- Layer norms (learnable gain)
    self.gamma1 = {}; for i=1,d do self.gamma1[i]=1.0 end

    -- Recurrent state h  (dim N, persists within sequence)
    self.h = zeros(N)

    -- MoE (8 experts, top-2 active)
    self.moe = self:_init_moe(d, 8, 2, seed+100)

    return self
end

function Block:_init_moe(d, n_exp, top_k, seed)
    local moe = { d=d, n_exp=n_exp, top_k=top_k }
    moe.router = rand_mat(n_exp, d, seed)
    moe.W_up   = {}; moe.W_down = {}
    for e=1,n_exp do
        moe.W_up[e]   = rand_mat(d*4, d, seed+e*2)
        moe.W_down[e] = rand_mat(d, d*4, seed+e*2+1)
    end
    return moe
end

function Block:_moe_forward(x)
    local moe = self.moe
    -- Route
    local logits = matvec(moe.router, rms_norm(x))
    local probs  = softmax_temp(logits, 1.0)
    -- Top-K selection
    local sorted = {}
    for i=1,moe.n_exp do sorted[i]={i=i,p=probs[i]} end
    table.sort(sorted, function(a,b) return a.p>b.p end)

    local out = zeros(self.d)
    for k=1,moe.top_k do
        local e,w = sorted[k].i, sorted[k].p
        local up  = matvec(moe.W_up[e], x)
        for i=1,#up do up[i]=silu(up[i]) end
        local dn = matvec(moe.W_down[e], up)
        for i=1,self.d do out[i]=out[i]+w*dn[i] end
    end
    return vec_add(x, out)   -- residual
end

-- Forward one token
-- x_in:     (d)  residual stream
-- tok_strs: list of context token strings for Engram
-- cur_hash: hash32 of current state key (for TC lookup)
function Block:step(x_in, tok_strs, cur_hash)
    local d,N = self.d, self.N

    -- ── 1. Input projection + gate split ──────────────────────
    local x_norm = rms_norm(x_in, d)
    local xg     = matvec(self.W_in, x_norm)   -- (2d)
    local x_ssm, z = {}, {}
    for i=1,d do x_ssm[i]=xg[i] end
    for i=1,d do z[i]=xg[i+d] end
    for i=1,d do x_ssm[i]=silu(x_ssm[i]) end
    for i=1,d do z[i]=sigmoid(z[i]) end

    -- ── 2. TransitionCore conditioning ────────────────────────
    -- Query the hot table for current state; use transition probs
    -- to modulate the dt (timescale) parameter.
    local tc_scale = 1.0
    if cur_hash and self.store then
        local state_e = self.store.hot:get(cur_hash)
        if state_e and state_e.transitions and #state_e.transitions > 0 then
            -- Use max transition probability as a confidence signal
            local max_p = 0
            for _, t in ipairs(state_e.transitions) do
                local p = SS.Enc.prob_decode12(t.prob12)
                if p > max_p then max_p = p end
            end
            -- High-confidence transitions → shorten state horizon (faster scan)
            -- Low-confidence → expand horizon (more memory)
            tc_scale = 1.0 - 0.5 * max_p   -- [0.5, 1.0]
        end
    end

    -- ── 3. Selective SSM parameters (input-dependent) ─────────
    local B_t  = rms_norm(matvec(self.W_B, x_ssm))   -- (N)
    local C_t  = rms_norm(matvec(self.W_C, x_ssm))   -- (N)
    -- Δ (timescale): softplus(linear) scaled by TC confidence
    local dt_raw = matvec(self.W_dt, x_ssm)
    local dt_s   = 0
    for i=1,d do
        local dt_i = softplus(dt_raw[i]) * tc_scale
        dt_s = dt_s + math.min(math.max(dt_i, 0.001), 10.0)
    end
    dt_s = dt_s / d

    -- ── 4. Discretise A (ZOH scheme, log-scale) ───────────────
    --  log-scale 12-bit from spec §3: stored = -log2(prob)×256
    --  Here we use log_A for the state decay rates.
    local h_new = {}
    local x_sc  = 0
    for i=1,d do x_sc=x_sc+x_ssm[i] end; x_sc=x_sc/d

    for i=1,N do
        local A_i   = -math.exp(self.log_A[i])   -- continuous A (< 0)
        local Abar  = math.exp(dt_s * A_i)        -- ∈ (0,1)
        local Bbar  = (Abar-1)/A_i * B_t[i]       -- ZOH B
        h_new[i]    = Abar * self.h[i] + Bbar * x_sc
    end
    self.h = h_new

    -- ── 5. SSM output: y = C·h ───────────────────────────────
    local ch = 0
    for i=1,N do ch=ch+C_t[i]*self.h[i] end
    local y_ssm = {}
    for i=1,d do y_ssm[i]=ch end   -- broadcast

    -- ── 6. Gated output ──────────────────────────────────────
    local y = vec_mul(y_ssm, z)

    -- ── 7. Multi-branch Engram injection ─────────────────────
    local eng_v
    if self.engram and tok_strs and #tok_strs > 0 then
        eng_v = self.engram:retrieve_multibranch(tok_strs, x_in)
    else
        eng_v = zeros(d)
    end

    local e_proj  = matvec(self.W_engram, rms_norm(eng_v, d))
    local e_norm  = rms_norm(e_proj, d)
    -- Gate by L2 magnitude of Engram output
    local e_mag   = 0
    for i=1,d do e_mag=e_mag+e_proj[i]*e_proj[i] end
    e_mag = math.sqrt(e_mag/(d+1e-9))
    local e_gate  = sigmoid(e_mag - 0.5)
    for i=1,d do y[i]=y[i]+e_gate*e_proj[i] end

    -- ── 8. Output projection + residual ──────────────────────
    local y_out = vec_add(x_in, matvec(self.W_out, rms_norm(y, d)))

    -- ── 9. MoE FFN ──────────────────────────────────────────
    y_out = self:_moe_forward(y_out)

    return y_out
end

function Block:reset() self.h = zeros(self.N) end

-- ────────────────────────────────────────────────────────────────
--  Full SSM Model v2
-- ────────────────────────────────────────────────────────────────

function SSM.new(cfg, engram, store)
    local self      = setmetatable({}, SSM)
    self.d          = cfg.d          or 128
    self.N          = cfg.N          or 32
    self.n_layers   = cfg.n_layers   or 4
    self.vocab_size = cfg.vocab_size or 50000
    self.engram     = engram
    self.store      = store

    -- Token embedding (lazy init)
    self.embed = {}

    -- SSM blocks
    self.blocks = {}
    for l=1,self.n_layers do
        self.blocks[l] = Block.new(self.d, self.N, engram, store, l*1000)
    end

    -- Output head (vocab_size × d)
    self.W_head  = rand_mat(self.vocab_size, self.d, 9999)
    self.norm_out = {}
    for i=1,self.d do self.norm_out[i]=1.0 end

    -- Token history for Engram context
    self.tok_history = {}
    self.max_context = cfg.max_context or 64
    return self
end

function SSM:_get_embed(id)
    if not self.embed[id] then
        self.embed[id] = rand_vec(self.d, id*37+1)
    end
    return self.embed[id]
end

-- Forward one token step
-- tok_str: string  (actual token text)
-- tok_id:  int     (vocabulary id)
-- Returns: logits (vocab_size), hidden (d)
function SSM:forward_step(tok_str, tok_id)
    -- Update context
    table.insert(self.tok_history, tok_str)
    if #self.tok_history > self.max_context then
        table.remove(self.tok_history, 1)
    end

    -- Embed
    local emb_raw = self:_get_embed(tok_id)
    local h = {}
    for i=1,self.d do h[i]=emb_raw[i] end

    -- Current state key = last few tokens (trigram)
    local ctx_len = math.min(3, #self.tok_history)
    local ctx_parts = {}
    for i=#self.tok_history-ctx_len+1, #self.tok_history do
        ctx_parts[#ctx_parts+1] = self.tok_history[i]
    end
    local state_key  = table.concat(ctx_parts, "_")
    local state_hash = SS.Enc.fnv1a32(state_key)

    -- Get context window for Engram
    local ctx_start = math.max(1, #self.tok_history - 3)
    local ctx_toks  = {}
    for i=ctx_start, #self.tok_history do
        ctx_toks[#ctx_toks+1] = self.tok_history[i]
    end

    -- SSM blocks
    for l=1,self.n_layers do
        h = self.blocks[l]:step(h, ctx_toks, state_hash)
    end

    -- Output head
    local h_norm  = rms_norm(h, self.d)
    local logits  = matvec(self.W_head, h_norm)
    return logits, h
end

function SSM:reset()
    for l=1,self.n_layers do self.blocks[l]:reset() end
    self.tok_history = {}
end

-- ────────────────────────────────────────────────────────────────
--  Smart Decode Loop v2
--  Uses StateStore transition probabilities to bias beam scores.
--  Pattern Dictionary early-exit: if state matches a known pattern,
--  retrieve the template directly (O(1) vs O(L·d·N) scan).
-- ────────────────────────────────────────────────────────────────

function SSM:smart_decode(prompt_ids, prompt_toks, tokenizer, cfg)
    cfg = cfg or {}
    local max_gen   = cfg.max_gen   or 60
    local beam_w    = cfg.beam_width or 3
    local temp      = cfg.temperature or 0.8
    local top_k     = cfg.top_k     or 40
    local eos_id    = tokenizer.word2id and tokenizer.word2id["<eos>"] or 4

    -- ── Pattern Dictionary Early-Exit ─────────────────────────
    -- If the prompt matches a known state pattern, return instantly.
    local prompt_chain = {}
    for _, id in ipairs(prompt_ids) do
        prompt_chain[#prompt_chain+1] = SS.Enc.fnv1a32(tostring(id))
    end
    local pid, slots = self.store.pdict:match(prompt_chain)
    if pid then
        -- Expand pattern to get predicted continuation
        local expanded = self.store.pdict:expand(pid, slots)
        if expanded and #expanded > 0 then
            -- Decode hashes back to tokens (reverse lookup via TC)
            local gen_toks, gen_ids = {}, {}
            for _, h in ipairs(expanded) do
                local w = tokenizer.id2word and tokenizer.id2word[h % self.vocab_size] or "<unk>"
                gen_toks[#gen_toks+1] = w
                gen_ids[#gen_ids+1]   = h % self.vocab_size
            end
            print("[SSM] Pattern early-exit (pid=" .. pid .. ")")
            return gen_ids, gen_toks, nil
        end
    end

    -- ── TC-guided Beam Search ─────────────────────────────────
    -- For each beam position, query TransitionCore for high-prob
    -- next states and blend with SSM logits.
    local candidates = {}

    for beam = 1, beam_w do
        self:reset()
        -- Feed prompt
        local last_h
        for i, pid2 in ipairs(prompt_ids) do
            local _, h = self:forward_step(prompt_toks[i], pid2)
            last_h = h
        end

        local gen_ids, gen_toks = {}, {}
        local lp_sum = 0.0
        local beam_temp = temp * (0.7 + beam * 0.15)

        for step=1,max_gen do
            local cur_tok = gen_toks[#gen_toks] or prompt_toks[#prompt_toks] or ""
            local cur_id  = gen_ids[#gen_ids]   or prompt_ids[#prompt_ids]   or 1

            local logits, h = self:forward_step(cur_tok, cur_id)
            last_h = h

            -- ── TC probability blending ────────────────────────
            -- Build state key from recent context
            local ctx_words = {}
            for i=math.max(1,#self.tok_history-2), #self.tok_history do
                ctx_words[#ctx_words+1] = self.tok_history[i]
            end
            local skey  = table.concat(ctx_words, "_")
            local shash = SS.Enc.fnv1a32(skey)
            local se    = self.store.hot:get(shash)

            if se and se.transitions then
                -- Boost logits of states with high TC probability
                for _, t in ipairs(se.transitions) do
                    local tid = t.target % self.vocab_size
                    local tc_prob = SS.Enc.prob_decode12(t.prob12)
                    if tc_prob > 0.01 then
                        local bonus = math.log(tc_prob + 1e-9) * 0.3
                        logits[tid+1] = (logits[tid+1] or 0) + bonus
                    end
                end
            end

            -- Top-K sampling with temperature
            local scaled = {}
            for i=1,#logits do scaled[i]={i=i,v=logits[i]/beam_temp} end
            table.sort(scaled, function(a,b) return a.v>b.v end)
            -- Softmax over top-k
            local mx=scaled[1].v
            local sm_sum=0; local top={}
            for i=1,math.min(top_k,#scaled) do
                local e=math.exp(scaled[i].v-mx)
                top[i]={i=scaled[i].i,p=e}; sm_sum=sm_sum+e
            end
            for i=1,#top do top[i].p=top[i].p/sm_sum end
            local r=math.random(); local cdf=0; local next_id=top[1].i
            for _,t in ipairs(top) do
                cdf=cdf+t.p
                if r<=cdf then next_id=t.i; break end
            end

            local next_tok = tokenizer.id2word and tokenizer.id2word[next_id] or "<unk>"
            gen_ids[#gen_ids+1]   = next_id
            gen_toks[#gen_toks+1] = next_tok
            lp_sum = lp_sum + (logits[next_id] or -10)

            if next_id == eos_id then break end
            if next_tok == "." and step > 8 then break end
            if #gen_ids >= max_gen then break end
        end

        -- Beam score: log-prob normalised by length^0.6 (length penalty)
        local score = lp_sum / math.max(1, #gen_ids)^0.6
        candidates[beam] = { ids=gen_ids, toks=gen_toks, score=score, h=last_h }
    end

    -- Pick best beam
    table.sort(candidates, function(a,b) return a.score>b.score end)
    local best = candidates[1]
    return best.ids, best.toks, best.h
end

-- ── Save / Load ────────────────────────────────────────────────

function SSM:save(path)
    local f = assert(io.open(path, "w"))
    f:write("D="..self.d.."\nN="..self.N.."\nL="..self.n_layers.."\nV="..self.vocab_size.."\n")
    -- Save initialised embeddings
    for id, v in pairs(self.embed) do
        if v then f:write("EMB|"..id.."|"..table.concat(v,",").."\n") end
    end
    -- Save SSM block log_A (key parameter)
    for l=1,self.n_layers do
        f:write("LOGA|"..l.."|"..table.concat(self.blocks[l].log_A,",").."\n")
    end
    f:close()
    print("[SSM v2] Saved → " .. path)
end

function SSM:load(path)
    local f = io.open(path, "r")
    if not f then print("[SSM v2] No checkpoint"); return false end
    for line in f:lines() do
        if line:sub(1,3)=="EMB" then
            local id, vals = line:match("EMB|(%d+)|(.+)")
            if id then
                local v={}; for s in vals:gmatch("[^,]+") do v[#v+1]=tonumber(s) end
                self.embed[tonumber(id)]=v
            end
        elseif line:sub(1,4)=="LOGA" then
            local l, vals = line:match("LOGA|(%d+)|(.+)")
            l=tonumber(l)
            if l and self.blocks[l] then
                local v={}; for s in vals:gmatch("[^,]+") do v[#v+1]=tonumber(s) end
                self.blocks[l].log_A=v
            end
        end
    end
    f:close()
    print("[SSM v2] Loaded from " .. path)
    return true
end

return SSM
